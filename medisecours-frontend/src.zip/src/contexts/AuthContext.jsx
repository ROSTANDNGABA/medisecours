'use client'

import { createContext, useContext, useState, useCallback, useEffect } from 'react'
import api from '../api/axios'
import { setAuthCookie, clearAuthCookie } from '../lib/cookies'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  /**
   * RÈGLE D'OR Next.js App Router :
   * Ne jamais lire localStorage dans l'initializer du useState.
   * Le serveur ne connaît pas localStorage → il rend null.
   * Le client lit la valeur stockée → mismatch hydration → crash.
   *
   * Solution : initialiser à null/false, puis lire localStorage
   * dans un useEffect (qui ne s'exécute QUE côté client, après hydration).
   */
  const [user,    setUser]    = useState(null)
  const [token,   setToken]   = useState(null)
  const [mounted, setMounted] = useState(false)

  // Chargement depuis localStorage UNIQUEMENT après hydration complète
  useEffect(() => {
    const storedToken = localStorage.getItem('medisecours_token')
    const storedUser  = localStorage.getItem('medisecours_user')
    if (storedToken) setToken(storedToken)
    if (storedUser)  {
      try {
        setUser(JSON.parse(storedUser))
      } catch {
        localStorage.removeItem('medisecours_user')
      }
    }
    setMounted(true)
  }, [])

  const persist = useCallback((newToken, newUser) => {
    localStorage.setItem('medisecours_token', newToken)
    localStorage.setItem('medisecours_user', JSON.stringify(newUser))
    setAuthCookie(newToken)
    setToken(newToken)
    setUser(newUser)
  }, [])

  const login = useCallback(async (email, password) => {
    const { data } = await api.post('/api/auth/login', { email, password })
    persist(data.token, data.user)
    return data.user
  }, [persist])

  const loginWithGoogle = useCallback(async (googleIdToken) => {
    const { data } = await api.post('/api/auth/google', { googleIdToken })
    persist(data.token, data.user)
    return data.user
  }, [persist])

  const register = useCallback(async (payload) => {
    const { data } = await api.post('/api/auth/register', payload)
    return data
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem('medisecours_token')
    localStorage.removeItem('medisecours_user')
    clearAuthCookie()
    setToken(null)
    setUser(null)
  }, [])

  const updateUser = useCallback((newUser) => {
    localStorage.setItem('medisecours_user', JSON.stringify(newUser))
    setUser(newUser)
  }, [])

  // `mounted` indique que l'hydration est terminée et que localStorage est lu.
  // Les composants qui dépendent de l'état auth doivent attendre mounted=true
  // avant de rendre du contenu conditionnel (évite le mismatch hydration).
  const isAuthenticated = mounted && Boolean(token)
  const isAdmin         = mounted && Boolean(user?.roles?.includes('ROLE_ADMIN'))
  const isMedecin       = mounted && Boolean(user?.roles?.includes('ROLE_MEDECIN'))

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        mounted,
        isAuthenticated,
        isAdmin,
        isMedecin,
        login,
        loginWithGoogle,
        register,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuthContext() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuthContext doit être utilisé dans un AuthProvider')
  return ctx
}
