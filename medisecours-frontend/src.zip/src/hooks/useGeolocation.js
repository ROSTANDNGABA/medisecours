'use client'

import { useState, useCallback } from 'react'

/**
 * Hook de géolocalisation sécurisé pour Next.js App Router.
 *
 * Problème d'hydration : `navigator` n'existe pas côté serveur.
 * Ce hook ne fait RIEN côté serveur — il s'active uniquement côté client
 * sur action explicite de l'utilisateur (bouton "Me localiser").
 * Aucun appel automatique au démarrage.
 */
export function useGeolocation() {
  const [position, setPosition] = useState(null)
  const [error,    setError]    = useState(null)
  const [loading,  setLoading]  = useState(false)

  const locate = useCallback(() => {
    // Sécurité SSR — ne jamais appeler navigator côté serveur
    if (typeof window === 'undefined' || !navigator?.geolocation) {
      setError("La géolocalisation n'est pas disponible sur cet appareil.")
      return
    }

    setLoading(true)
    setError(null)

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setPosition({ lat: pos.coords.latitude, lng: pos.coords.longitude })
        setLoading(false)
      },
      (err) => {
        const messages = {
          1: "Accès à la localisation refusé. Autorisez la géolocalisation dans votre navigateur.",
          2: "Position introuvable. Vérifiez que le GPS est activé.",
          3: "Délai dépassé. Réessayez dans une zone avec meilleur signal.",
        }
        setError(messages[err.code] ?? "Impossible d'obtenir votre position.")
        setLoading(false)
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }
    )
  }, [])

  return { position, error, loading, locate }
}
