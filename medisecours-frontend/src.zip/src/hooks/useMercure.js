'use client'

import { useEffect, useCallback, useRef } from 'react'

/**
 * Hook pour s'abonner à un topic Mercure (SSE — Server-Sent Events).
 *
 * Remplace le polling toutes les 8s par une connexion persistante push :
 * le serveur envoie les données uniquement quand elles changent,
 * sans aucune requête répétée côté client.
 *
 * Gère automatiquement :
 * - La reconnexion exponentielle en cas de coupure réseau (3G camerounaise)
 * - Le nettoyage de la connexion au démontage du composant
 * - Les erreurs silencieuses (Mercure indisponible → pas de crash)
 *
 * @param {string|null} topic - IRI du topic à écouter (ex: /api/users/uuid/messages)
 * @param {function} onMessage - Callback appelé avec le data parsé à chaque événement
 * @param {string|null} mercureToken - JWT Mercure pour les topics privés (optionnel)
 */
export function useMercure(topic, onMessage, mercureToken = null) {
  const esRef         = useRef(null)
  const retryRef      = useRef(0)
  const retryTimerRef = useRef(null)
  const onMessageRef  = useRef(onMessage)

  // Garde la ref du callback à jour sans re-créer l'abonnement
  useEffect(() => { onMessageRef.current = onMessage }, [onMessage])

  const subscribe = useCallback(() => {
    // Sécurité SSR — EventSource n'existe pas côté serveur
    if (!topic || typeof window === 'undefined') return

    const mercureUrl = process.env.NEXT_PUBLIC_MERCURE_URL
    if (!mercureUrl) {
      // Mercure non configuré — fallback silencieux
      console.warn('[useMercure] NEXT_PUBLIC_MERCURE_URL non défini. Temps réel désactivé.')
      return
    }

    const url = new URL(mercureUrl)
    url.searchParams.append('topic', topic)

    // Ajouter le token d'autorisation pour les topics privés
    const headers = {}
    if (mercureToken) {
      // Mercure supporte l'auth par cookie ou par header Authorization
      // On utilise le query param 'authorization' car les EventSource ne supportent pas les headers custom
      url.searchParams.append('authorization', mercureToken)
    }

    const es = new EventSource(url.toString(), { withCredentials: true })
    esRef.current = es

    es.onopen = () => {
      retryRef.current = 0 // Reset du compteur de retry à la connexion réussie
    }

    es.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        onMessageRef.current(data)
      } catch {
        // Message non-JSON ignoré silencieusement
      }
    }

    es.onerror = () => {
      es.close()
      esRef.current = null

      // Reconnexion exponentielle : 1s, 2s, 4s, 8s, max 30s
      // Adapté au réseau africain qui peut avoir des coupures fréquentes
      const delay = Math.min(1000 * Math.pow(2, retryRef.current), 30000)
      retryRef.current += 1

      retryTimerRef.current = setTimeout(() => {
        subscribe()
      }, delay)
    }
  }, [topic, mercureToken]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    subscribe()

    return () => {
      // Nettoyage propre : fermer la connexion SSE et annuler le timer de retry
      if (retryTimerRef.current) {
        clearTimeout(retryTimerRef.current)
        retryTimerRef.current = null
      }
      if (esRef.current) {
        esRef.current.close()
        esRef.current = null
      }
    }
  }, [subscribe])
}
