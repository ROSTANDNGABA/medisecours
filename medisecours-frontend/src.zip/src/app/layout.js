import "./globals.css"
import Providers from "./providers"

export const metadata = {
  title: "MediSecours+ | Les premiers gestes qui sauvent",
  description: "Plateforme médicale d'urgence pour le Cameroun : premiers soins, centres de santé, messagerie médecins.",
}

export default function RootLayout({ children }) {
  return (
    <html lang="fr" className="h-full antialiased">
      <body className="min-h-full flex flex-col">
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
