'use client'

import { useEffect, useMemo, useRef, useState, useCallback } from 'react'
import { ArrowLeft, Send, Stethoscope, CheckCheck, Check, Plus, X } from 'lucide-react'
import api from '../../api/axios'
import { useAuth } from '../../hooks/useAuth'
import { useMercure } from '../../hooks/useMercure'
import LoadingSpinner from '../../components/ui/LoadingSpinner'
import EmptyState from '../../components/ui/EmptyState'
import { useToast } from '../../components/ui/Toast'

// ─── Helpers IRI ──────────────────────────────────────────────────────────────

function iri(id) { return `/api/users/${id}` }

function idFromIri(value) {
  if (!value) return null
  if (typeof value === 'object') return value.id ?? null
  const parts = String(value).split('/')
  return parts[parts.length - 1] || null
}

// ─── Composant principal ──────────────────────────────────────────────────────

export default function MessagesPage() {
  const { user, mounted } = useAuth()
  const toast    = useToast()

  const [messages,  setMessages]  = useState([])
  const [loading,   setLoading]   = useState(true)
  const [activeId,  setActiveId]  = useState(null)
  const [draft,     setDraft]     = useState('')
  const [sending,   setSending]   = useState(false)
  const [showNew,   setShowNew]   = useState(false)
  const [medecins,  setMedecins]  = useState([])
  const [hasMore,   setHasMore]   = useState(false)
  const [page,      setPage]      = useState(1)
  const bottomRef = useRef(null)
  const ITEMS_PER_PAGE = 30

  // ── Chargement initial paginé ──────────────────────────────────────────────
  const loadMessages = useCallback(async (pageNum = 1, append = false) => {
    try {
      const res = await api.get('/api/messages', {
        params: { page: pageNum, itemsPerPage: ITEMS_PER_PAGE },
      })
      const data  = res.data['hydra:member'] || res.data.member || []
      const total = res.data['hydra:totalItems'] ?? data.length

      setMessages((prev) => append ? [...data, ...prev] : data)
      setHasMore(pageNum * ITEMS_PER_PAGE < total)
    } catch {
      toast.error('Impossible de charger la messagerie.')
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    if (!mounted) return
    loadMessages(1)
  }, [loadMessages, mounted])

  // Charger les messages plus anciens (pagination vers le haut)
  const loadOlder = () => {
    const next = page + 1
    setPage(next)
    loadMessages(next, true)
  }

  // Mercure SSE — uniquement après hydration (user.id disponible)
  const mercureTopic = (mounted && user?.id)
    ? `/api/users/${user.id}/messages`
    : null

  const onMercureMessage = useCallback((data) => {
    // Un nouveau message est arrivé en temps réel via Mercure
    setMessages((prev) => {
      // Éviter les doublons si le message arrive aussi via l'API
      if (prev.some((m) => m.id === data.id)) return prev
      return [...prev, data]
    })
  }, [])

  useMercure(mercureTopic, onMercureMessage)

  // ── Groupement en conversations ───────────────────────────────────────────
  const conversations = useMemo(() => {
    const map = new Map()

    for (const m of messages) {
      const expId  = idFromIri(m.expediteur)
      const destId = idFromIri(m.destinataire)
      const other  = expId === user?.id ? destId : expId
      if (!other) continue

      const otherInfo = expId === user?.id ? m.destinataire : m.expediteur
      const existing  = map.get(other) ?? { id: other, info: otherInfo, messages: [], unread: 0 }

      existing.messages.push(m)
      // Garder l'objet enrichi (pas juste l'IRI)
      if (otherInfo && typeof otherInfo === 'object') existing.info = otherInfo

      // Fix : le champ API s'appelle `isRead` (backend PHP → JSON camelCase)
      // L'ancienne version utilisait `m.lu` qui ne correspond à aucun champ réel
      const isUnread = destId === user?.id && m.isRead === false
      if (isUnread) existing.unread += 1

      map.set(other, existing)
    }

    return Array.from(map.values()).sort((a, b) => {
      const lastA = a.messages.at(-1)?.createdAt ?? ''
      const lastB = b.messages.at(-1)?.createdAt ?? ''
      return lastB.localeCompare(lastA)
    })
  }, [messages, user])

  const active = conversations.find((c) => c.id === activeId)

  // Scroll vers le bas quand un nouveau message arrive
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [active?.messages?.length])

  // ── Chargement liste médecins ─────────────────────────────────────────────
  const openNewConversation = () => {
    setShowNew(true)
    if (medecins.length === 0) {
      api.get('/api/medecins-publics')
        .then((res) => {
          const data = res.data['hydra:member'] || res.data.medecins || res.data || []
          setMedecins(Array.isArray(data) ? data : [])
        })
        .catch(() => toast.error('Impossible de charger la liste des médecins.'))
    }
  }

  // ── Envoi de message ──────────────────────────────────────────────────────
  const handleSend = async () => {
    if (!draft.trim() || !activeId) return
    setSending(true)
    try {
      const { data } = await api.post(
        '/api/messages',
        { contenu: draft.trim(), destinataire: iri(activeId) },
        { headers: { 'Content-Type': 'application/ld+json' } }
      )
      // Ajouter optimistiquement le message envoyé
      setMessages((prev) => [...prev, data])
      setDraft('')
    } catch {
      toast.error("Échec de l'envoi du message.")
    } finally {
      setSending(false)
    }
  }

  // ── Marquer comme lu ──────────────────────────────────────────────────────
  const markAsRead = useCallback(async (msg) => {
    // Fix : utiliser `isRead` (nom réel du champ) au lieu de `lu`
    if (msg.isRead || idFromIri(msg.destinataire) !== user?.id) return
    try {
      await api.patch(
        `/api/messages/${msg.id}`,
        { isRead: true },
        { headers: { 'Content-Type': 'application/merge-patch+json' } }
      )
      setMessages((all) => all.map((m) => m.id === msg.id ? { ...m, isRead: true } : m))
    } catch { /* silencieux — pas bloquant */ }
  }, [user?.id])

  useEffect(() => {
    active?.messages.forEach(markAsRead)
  }, [active, markAsRead])

  // ── Render ────────────────────────────────────────────────────────────────
  if (!mounted) return <LoadingSpinner label="Chargement…" />
  if (loading)  return <LoadingSpinner label="Chargement de la messagerie…" />

  return (
    <div className="max-w-6xl mx-auto px-0 sm:px-6 py-0 sm:py-10">
      <div className="grid grid-cols-1 md:grid-cols-3 h-[80vh] sm:rounded-2xl overflow-hidden border border-primary-100 dark:border-white/10 shadow-xl">

        {/* ── Colonne gauche : liste des conversations ── */}
        <div className={`md:col-span-1 border-r border-primary-100 dark:border-white/10 bg-white/70 dark:bg-primary-700/40 flex flex-col ${activeId ? 'hidden md:flex' : 'flex'}`}>
          <div className="flex items-center justify-between p-4 border-b border-primary-100 dark:border-white/10">
            <h2 className="font-display font-bold text-primary-900 dark:text-sable">Messages</h2>
            <button
              onClick={openNewConversation}
              className="p-2 rounded-xl bg-mint-500 text-white"
              aria-label="Nouvelle conversation"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {conversations.length === 0 ? (
              <EmptyState
                title="Aucune conversation"
                description="Démarrez une conversation avec un médecin."
              />
            ) : (
              conversations.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActiveId(c.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-primary-100/50 dark:hover:bg-primary-900/40 transition ${activeId === c.id ? 'bg-primary-100/70 dark:bg-primary-900/60' : ''}`}
                >
                  <div className="w-10 h-10 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold text-sm shrink-0">
                    {(c.info?.prenom?.[0] ?? '') + (c.info?.nom?.[0] ?? '')}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-primary-900 dark:text-sable truncate">
                      {c.info?.prenom} {c.info?.nom}
                    </p>
                    <p className="text-xs text-primary-300 truncate">
                      {c.messages.at(-1)?.contenu ?? ''}
                    </p>
                  </div>
                  {c.unread > 0 && (
                    <span className="w-5 h-5 rounded-full bg-urgence-500 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                      {c.unread}
                    </span>
                  )}
                </button>
              ))
            )}
          </div>
        </div>

        {/* ── Colonne droite : conversation active ── */}
        <div className={`md:col-span-2 flex flex-col bg-sable dark:bg-primary-900 ${activeId ? 'flex' : 'hidden md:flex'}`}>
          {active ? (
            <>
              {/* En-tête */}
              <div className="flex items-center gap-3 p-4 border-b border-primary-100 dark:border-white/10 bg-white/70 dark:bg-primary-700/40">
                <button className="md:hidden" onClick={() => setActiveId(null)} aria-label="Retour">
                  <ArrowLeft className="w-5 h-5 text-primary-500" />
                </button>
                <div className="w-9 h-9 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  {(active.info?.prenom?.[0] ?? '') + (active.info?.nom?.[0] ?? '')}
                </div>
                <p className="font-semibold text-sm text-primary-900 dark:text-sable">
                  {active.info?.prenom} {active.info?.nom}
                </p>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {/* Bouton charger messages plus anciens */}
                {hasMore && (
                  <div className="text-center pb-2">
                    <button
                      onClick={loadOlder}
                      className="text-xs text-primary-400 hover:text-mint-500 underline underline-offset-2"
                    >
                      Charger les messages précédents
                    </button>
                  </div>
                )}

                {active.messages.map((m) => {
                  const mine = idFromIri(m.expediteur) === user?.id
                  return (
                    <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${mine
                          ? 'bg-mint-500 text-white rounded-br-sm'
                          : 'bg-white dark:bg-primary-700 text-primary-900 dark:text-sable rounded-bl-sm'
                      }`}>
                        <p>{m.contenu}</p>
                        {/* Fix : `m.isRead` au lieu de `m.lu` */}
                        {mine && (
                          <span className="flex justify-end mt-1">
                            {m.isRead
                              ? <CheckCheck className="w-3.5 h-3.5 opacity-80" />
                              : <Check className="w-3.5 h-3.5 opacity-60" />
                            }
                          </span>
                        )}
                      </div>
                    </div>
                  )
                })}
                <div ref={bottomRef} />
              </div>

              {/* Zone de saisie */}
              <div className="p-3 border-t border-primary-100 dark:border-white/10 flex items-center gap-2 bg-white/70 dark:bg-primary-700/40">
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() } }}
                  placeholder="Écrire un message…"
                  aria-label="Zone de saisie du message"
                  className="flex-1 px-4 py-2.5 rounded-2xl border border-primary-100 dark:border-white/10 bg-white dark:bg-primary-900/60 focus:outline-none focus:ring-2 focus:ring-mint-500"
                />
                <button
                  onClick={handleSend}
                  disabled={sending || !draft.trim()}
                  aria-label="Envoyer le message"
                  className="p-3 rounded-2xl bg-mint-500 hover:bg-mint-700 text-white disabled:opacity-50 transition"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <EmptyState
              icon={Stethoscope}
              title="Sélectionnez une conversation"
              description="Choisissez un médecin pour démarrer la discussion."
            />
          )}
        </div>
      </div>

      {/* ── Modal nouvelle conversation ── */}
      {showNew && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-6"
          onClick={() => setShowNew(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Nouvelle conversation"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white dark:bg-primary-700 rounded-2xl shadow-glass w-full max-w-sm p-5"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold text-primary-900 dark:text-sable">
                Nouvelle conversation
              </h3>
              <button onClick={() => setShowNew(false)} aria-label="Fermer">
                <X className="w-5 h-5 text-primary-300" />
              </button>
            </div>

            <div className="space-y-1 max-h-72 overflow-y-auto">
              {medecins.length === 0 ? (
                <LoadingSpinner size="sm" label="Chargement des médecins…" />
              ) : (
                medecins.map((med) => (
                  <button
                    key={med.id}
                    onClick={() => { setActiveId(med.id); setShowNew(false) }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-primary-100 dark:hover:bg-primary-900/40 text-left transition"
                  >
                    <div className="w-9 h-9 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      {(med.prenom?.[0] ?? '') + (med.nom?.[0] ?? '')}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-primary-900 dark:text-sable truncate">
                        Dr {med.prenom} {med.nom}
                      </p>
                      <p className="text-xs text-primary-300 truncate">{med.specialite}</p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
