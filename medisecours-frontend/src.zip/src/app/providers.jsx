'use client'

import { usePathname } from 'next/navigation'
import { GoogleOAuthProvider } from '@react-oauth/google'
import { SWRConfig } from 'swr'
import { AuthProvider } from '../contexts/AuthContext'
import { ToastProvider } from '../components/ui/Toast'
import Navbar from '../components/layout/Navbar'
import Footer from '../components/layout/Footer'
import { swrConfig } from '../lib/fetcher'

const GOOGLE_CLIENT_ID = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || ''

if (!GOOGLE_CLIENT_ID && process.env.NODE_ENV === 'development') {
  console.warn(
    '[MediSecours+] NEXT_PUBLIC_GOOGLE_CLIENT_ID manquant dans .env.local. La connexion Google ne fonctionnera pas.'
  )
}

export default function Providers({ children }) {
  const pathname = usePathname()
  const isAdminRoute = pathname?.startsWith('/admin')

  return (
    <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
      <AuthProvider>
        <SWRConfig value={swrConfig}>
          <ToastProvider>
            {!isAdminRoute && <Navbar />}
            <main className={isAdminRoute ? '' : 'flex-1'}>{children}</main>
            {!isAdminRoute && <Footer />}
          </ToastProvider>
        </SWRConfig>
      </AuthProvider>
    </GoogleOAuthProvider>
  )
}
