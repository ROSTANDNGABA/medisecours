'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { User, Mail, Phone, Save, Database, Info, RefreshCw, Shield, HeartPulse, Clock } from 'lucide-react'
import { useAuth } from '../../../hooks/useAuth'
import { useToast } from '../../../components/ui/Toast'
import api from '../../../api/axios'

export default function ParametresPage() {
  const { user, updateUser } = useAuth()
  const toast = useToast()
  const [form, setForm] = useState({
    prenom: user?.prenom || '',
    nom: user?.nom || '',
    email: user?.email || '',
    telephone: user?.telephone || '',
  })
  const [saving, setSaving] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      const { data } = await api.patch(
        `/api/users/${user.id}`,
        form,
        { headers: { 'Content-Type': 'application/merge-patch+json' } }
      )
      updateUser(data)
      toast.success('Profil mis à jour avec succès')
    } catch {
      toast.error('Erreur lors de la mise à jour du profil')
    } finally {
      setSaving(false)
    }
  }

  const getInitials = () => {
    if (!user) return 'A'
    const first = user.prenom?.[0] || user.nom?.[0] || user.email?.[0] || 'A'
    const last = user.nom?.[0] || ''
    return (first + last).toUpperCase()
  }

  return (
    <div id="admin-parametres" className="max-w-4xl mx-auto space-y-6">
      {/* Profile section */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm overflow-hidden"
      >
        <div className="px-6 py-5 border-b border-primary-100/50 dark:border-white/5">
          <h3 className="font-display font-semibold text-lg text-primary-900 dark:text-sable">
            Profil Administrateur
          </h3>
          <p className="text-sm text-primary-300/70 mt-0.5">
            Gérez vos informations personnelles
          </p>
        </div>

        <div className="p-6">
          <div className="flex items-center gap-6 mb-8">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-mint-500 to-mint-600 flex items-center justify-center text-white font-bold text-2xl shadow-md shadow-mint-500/20">
                {getInitials()}
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-mint-500 border-2 border-white dark:border-primary-800 flex items-center justify-center">
                <Shield className="w-2.5 h-2.5 text-white" strokeWidth={3} />
              </div>
            </div>
            <div>
              <p className="font-display font-semibold text-xl text-primary-900 dark:text-sable">
                {user?.prenom} {user?.nom}
              </p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-mint-500/10 text-mint-600 dark:text-mint-400">
                  <Shield className="w-3 h-3" strokeWidth={2.5} />
                  Administrateur
                </span>
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-primary-100/50 dark:bg-white/5 text-primary-400">
                  <HeartPulse className="w-3 h-3" strokeWidth={2} />
                  MediSecours+
                </span>
              </div>
            </div>
          </div>

          <form id="admin-profile-form" onSubmit={handleSubmit} className="space-y-5">
            <div className="grid sm:grid-cols-2 gap-5">
              <FormField
                id="admin-prenom"
                label="Prénom"
                icon={User}
                value={form.prenom}
                onChange={(v) => setForm({ ...form, prenom: v })}
              />
              <FormField
                id="admin-nom"
                label="Nom"
                icon={User}
                value={form.nom}
                onChange={(v) => setForm({ ...form, nom: v })}
              />
            </div>
            <FormField
              id="admin-email"
              label="Email"
              type="email"
              icon={Mail}
              value={form.email}
              onChange={(v) => setForm({ ...form, email: v })}
            />
            <FormField
              id="admin-telephone"
              label="Téléphone"
              type="tel"
              icon={Phone}
              value={form.telephone}
              onChange={(v) => setForm({ ...form, telephone: v })}
              placeholder="+237 6XX XXX XXX"
            />

            <div className="pt-2">
              <button
                id="save-profile"
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-mint-500 to-mint-600 hover:from-mint-600 hover:to-mint-700 text-white font-semibold shadow-lg shadow-mint-500/20 hover:shadow-mint-500/30 transition-all duration-200 disabled:opacity-60"
              >
                <Save className="w-4 h-4" strokeWidth={2} />
                {saving ? 'Enregistrement…' : 'Enregistrer les modifications'}
              </button>
            </div>
          </form>
        </div>
      </motion.div>

      {/* Platform info */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.08 }}
        className="rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm overflow-hidden"
      >
        <div className="px-6 py-5 border-b border-primary-100/50 dark:border-white/5">
          <h3 className="font-display font-semibold text-lg text-primary-900 dark:text-sable">
            Informations Plateforme
          </h3>
        </div>
        <div className="p-6 space-y-3">
          <InfoRow icon={Info} label="Version" value="MediSecours+ v1.0.0" />
          <InfoRow
            icon={Database}
            label="Environnement"
            value={process.env.NODE_ENV === 'production' ? 'Production' : 'Développement'}
          />
          <InfoRow
            icon={Clock}
            label="Dernière mise à jour"
            value={new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}
          />
        </div>
      </motion.div>

      {/* Quick actions */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12 }}
        className="rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm overflow-hidden"
      >
        <div className="px-6 py-5 border-b border-primary-100/50 dark:border-white/5">
          <h3 className="font-display font-semibold text-lg text-primary-900 dark:text-sable">
            Actions Rapides
          </h3>
        </div>
        <div className="p-6 space-y-3">
          <ActionButton
            id="clear-cache"
            icon={RefreshCw}
            title="Actualiser le cache"
            description="Vider le cache de l'application (bientôt disponible)"
          />
          <ActionButton
            id="detailed-stats"
            icon={Database}
            title="Statistiques détaillées"
            description="Exporter les statistiques de la plateforme (bientôt disponible)"
          />
        </div>
      </motion.div>
    </div>
  )
}

function FormField({ id, label, icon: Icon, type = 'text', value, onChange, placeholder }) {
  return (
    <div>
      <label htmlFor={id} className="text-[11px] font-bold text-primary-400 uppercase tracking-wider mb-1.5 block">
        {label}
      </label>
      <div className="relative">
        <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-primary-300" strokeWidth={1.5} />
        <input
          id={id}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-primary-100/60 dark:border-white/10 bg-white/80 dark:bg-primary-900/40 focus:outline-none focus:ring-2 focus:ring-mint-500/40 focus:border-mint-500 transition-all text-sm text-primary-900 dark:text-sable placeholder:text-primary-300/50"
        />
      </div>
    </div>
  )
}

function InfoRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-3 p-3.5 rounded-xl bg-primary-50/50 dark:bg-white/[0.02] border border-primary-100/30 dark:border-white/5">
      <div className="w-9 h-9 rounded-lg bg-primary-100/50 dark:bg-white/5 flex items-center justify-center shrink-0">
        <Icon className="w-4.5 h-4.5 text-primary-400" strokeWidth={1.5} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-bold text-primary-400 uppercase tracking-wider">{label}</p>
        <p className="text-sm font-medium text-primary-900 dark:text-sable mt-0.5">{value}</p>
      </div>
    </div>
  )
}

function ActionButton({ id, icon: Icon, title, description }) {
  return (
    <button
      id={id}
      disabled
      className="w-full flex items-center gap-4 p-4 rounded-xl border border-primary-100/60 dark:border-white/5 hover:bg-primary-50/50 dark:hover:bg-white/[0.02] text-left transition-all duration-200 opacity-60 cursor-not-allowed"
    >
      <div className="w-10 h-10 rounded-lg bg-primary-100/50 dark:bg-white/5 flex items-center justify-center shrink-0">
        <Icon className="w-4.5 h-4.5 text-primary-400" strokeWidth={1.5} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm text-primary-900 dark:text-sable">{title}</p>
        <p className="text-xs text-primary-300/60">{description}</p>
      </div>
    </button>
  )
}
