'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Star,
  AlertTriangle,
  Trash2,
  CheckCircle,
  PartyPopper,
  Flag,
  ChevronDown,
  ChevronUp,
  User,
  Stethoscope,
  Clock,
} from 'lucide-react'
import api from '../../../api/axios'
import LoadingSpinner from '../../../components/ui/LoadingSpinner'
import EmptyState from '../../../components/ui/EmptyState'
import { useToast } from '../../../components/ui/Toast'

const severityConfig = {
  spam: { label: 'Spam', color: 'text-primary-400', bg: 'bg-primary-100/50 dark:bg-primary-900/20', bar: 'bg-primary-400' },
  inapproprié: { label: 'Inapproprié', color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/10', bar: 'bg-amber-500' },
  faux: { label: 'Avis frauduleux', color: 'text-urgence-600', bg: 'bg-urgence-50 dark:bg-urgence-900/10', bar: 'bg-urgence-500' },
  confidentiel: { label: 'Info confidentielle', color: 'text-urgence-600', bg: 'bg-urgence-50 dark:bg-urgence-900/10', bar: 'bg-urgence-500' },
}

function getSeverity(reason) {
  if (!reason) return { label: 'Signalé', color: 'text-urgence-500', bg: 'bg-urgence-50 dark:bg-urgence-900/10', bar: 'bg-urgence-500' }
  const lower = reason.toLowerCase()
  for (const [key, val] of Object.entries(severityConfig)) {
    if (lower.includes(key)) return val
  }
  return { label: 'Autre', color: 'text-primary-400', bg: 'bg-primary-100/50 dark:bg-primary-900/20', bar: 'bg-primary-400' }
}

export default function AvisPage() {
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [expandedId, setExpandedId] = useState(null)
  const [actionLoading, setActionLoading] = useState(null)
  const toast = useToast()

  const loadReviews = () => {
    setLoading(true)
    api.get('/api/avis?signale=true')
      .then((res) => {
        const data = res.data['hydra:member'] || res.data.member || res.data
        setReviews(Array.isArray(data) ? data : [])
      })
      .catch(() => toast.error('Impossible de charger les avis signalés'))
      .finally(() => setLoading(false))
  }

  useEffect(loadReviews, [])

  const handleDismiss = async (reviewId) => {
    setActionLoading(reviewId)
    try {
      await api.patch(
        `/api/avis/${reviewId}`,
        { signale: false },
        { headers: { 'Content-Type': 'application/merge-patch+json' } }
      )
      toast.success('Signalement rejeté')
      setReviews((prev) => prev.filter((r) => r.id !== reviewId))
    } catch {
      toast.error('Erreur lors du rejet du signalement')
    } finally {
      setActionLoading(null)
    }
  }

  const handleDelete = async (reviewId) => {
    if (!confirm('Supprimer définitivement cet avis ?')) return
    setActionLoading(reviewId)
    try {
      await api.delete(`/api/avis/${reviewId}`)
      toast.success('Avis supprimé')
      setReviews((prev) => prev.filter((r) => r.id !== reviewId))
    } catch {
      toast.error('Erreur lors de la suppression')
    } finally {
      setActionLoading(null)
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const renderStars = (note) => {
    return (
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-3.5 h-3.5 ${
              star <= note ? 'fill-amber-400 text-amber-400' : 'text-primary-200 dark:text-primary-600'
            }`}
            strokeWidth={1.2}
          />
        ))}
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <LoadingSpinner label="Chargement des avis signalés..." />
      </div>
    )
  }

  if (reviews.length === 0) {
    return (
      <div id="admin-avis-empty" className="max-w-lg mx-auto">
        <EmptyState
          icon={PartyPopper}
          title="Aucun avis signalé"
          description="Tous les avis sont en ordre. Vous serez notifié dès qu'un utilisateur signale un avis inapproprié."
        />
      </div>
    )
  }

  return (
    <div id="admin-avis" className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-xl text-primary-900 dark:text-sable">
            Avis signalés
          </h1>
          <p className="text-sm text-primary-300/70 mt-0.5">
            Modérez les avis signalés par les utilisateurs
          </p>
        </div>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-urgence-500/10 to-urgence-500/5 border border-urgence-500/20 text-urgence-700 dark:text-urgence-400 text-sm font-semibold">
          <Flag className="w-4 h-4" strokeWidth={2} />
          {reviews.length} avis signalé{reviews.length > 1 ? 's' : ''}
        </div>
      </div>

      {/* Review cards */}
      <div className="space-y-4">
        <AnimatePresence mode="popLayout">
          {reviews.map((review, index) => {
            const severity = getSeverity(review.raisonSignalement)
            const isExpanded = expandedId === review.id
            const isLongComment = review.commentaire?.length > 120
            const displayComment = isExpanded || !isLongComment
              ? review.commentaire
              : review.commentaire?.slice(0, 120) + '...'

            return (
              <motion.div
                key={review.id}
                id={`review-card-${review.id}`}
                layout
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -15 }}
                transition={{ delay: index * 0.03, duration: 0.25 }}
                className="relative pl-1 rounded-2xl bg-white dark:bg-primary-800 border border-urgence-200/60 dark:border-urgence-900/30 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden"
              >
                {/* Left severity bar */}
                <div className={`absolute left-0 top-0 bottom-0 w-1 ${severity.bar} rounded-l-full`} />

                <div className="px-6 pt-5 pb-4">
                  {/* Header row */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3 flex-wrap">
                      {/* Patient */}
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center text-white text-xs font-bold shadow-sm">
                          {review.patient?.prenom?.[0] || 'P'}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-primary-900 dark:text-sable">
                            {review.patient?.prenom} {review.patient?.nom}
                          </p>
                          <p className="text-[10px] text-primary-300/60">Patient</p>
                        </div>
                      </div>
                      <span className="text-primary-200 dark:text-primary-500">→</span>
                      {/* Doctor */}
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-mint-500 to-mint-600 flex items-center justify-center text-white text-xs font-bold shadow-sm">
                          {review.medecin?.prenom?.[0] || 'M'}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-primary-900 dark:text-sable">
                            Dr. {review.medecin?.prenom} {review.medecin?.nom}
                          </p>
                          <p className="text-[10px] text-primary-300/60">Médecin</p>
                        </div>
                      </div>
                    </div>
                    {/* Severity badge */}
                    <span className={`shrink-0 inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold border ${severity.bg} ${severity.color} border-current/10`}>
                      <AlertTriangle className="w-3 h-3" strokeWidth={2.5} />
                      {severity.label}
                    </span>
                  </div>

                  {/* Stars + Date */}
                  <div className="flex items-center gap-3 mb-3">
                    {renderStars(review.note)}
                    <span className="text-[11px] text-primary-300/60 font-medium">{formatDate(review.createdAt)}</span>
                  </div>

                  {/* Comment */}
                  {review.commentaire && (
                    <div className="mb-4">
                      <p className="text-sm text-primary-700 dark:text-primary-300 leading-relaxed">
                        &ldquo;{displayComment}&rdquo;
                      </p>
                      {isLongComment && (
                        <button
                          id={`toggle-comment-${review.id}`}
                          onClick={() => setExpandedId(isExpanded ? null : review.id)}
                          className="inline-flex items-center gap-1 mt-1 text-xs font-medium text-mint-500 hover:text-mint-700 transition-colors"
                        >
                          {isExpanded ? (
                            <>Voir moins <ChevronUp className="w-3 h-3" strokeWidth={2.5} /></>
                          ) : (
                            <>Lire la suite <ChevronDown className="w-3 h-3" strokeWidth={2.5} /></>
                          )}
                        </button>
                      )}
                    </div>
                  )}

                  {/* Report reason */}
                  {review.raisonSignalement && (
                    <div className="flex items-start gap-2.5 p-3 rounded-xl bg-gradient-to-r from-urgence-50 to-urgence-50/30 dark:from-urgence-900/10 dark:to-transparent border border-urgence-200/40 dark:border-urgence-900/20">
                      <AlertTriangle className="w-4 h-4 text-urgence-500 shrink-0 mt-0.5" strokeWidth={2} />
                      <div>
                        <p className="text-[10px] font-bold text-urgence-500 uppercase tracking-wider mb-0.5">
                          Motif du signalement
                        </p>
                        <p className="text-sm font-medium text-urgence-700 dark:text-urgence-400">
                          {review.raisonSignalement}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Actions footer */}
                <div className="px-6 py-3 bg-primary-50/50 dark:bg-white/[0.02] border-t border-primary-100/50 dark:border-white/5 flex gap-2">
                  <button
                    id={`dismiss-review-${review.id}`}
                    onClick={() => handleDismiss(review.id)}
                    disabled={actionLoading === review.id}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-mint-500 to-mint-600 hover:from-mint-600 hover:to-mint-700 text-white text-sm font-semibold shadow-sm transition-all duration-200 disabled:opacity-50"
                  >
                    {actionLoading === review.id ? (
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <CheckCircle className="w-4 h-4" strokeWidth={2.5} />
                    )}
                    Rejeter le signalement
                  </button>
                  <button
                    id={`delete-review-${review.id}`}
                    onClick={() => handleDelete(review.id)}
                    disabled={actionLoading === review.id}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-urgence-500 to-urgence-600 hover:from-urgence-600 hover:to-urgence-700 text-white text-sm font-semibold shadow-sm transition-all duration-200 disabled:opacity-50"
                  >
                    {actionLoading === review.id ? (
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" strokeWidth={2.5} />
                    )}
                    Supprimer l'avis
                  </button>
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>
    </div>
  )
}
