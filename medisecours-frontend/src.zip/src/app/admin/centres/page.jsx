'use client'

import { MapPin } from 'lucide-react'
import CrudTable from '../../../components/admin/CrudTable'

export default function CentresPage() {
  const fields = [
    { key: 'nom', label: 'Nom', type: 'text' },
    {
      key: 'type',
      label: 'Type',
      type: 'select',
      options: [
        'hopital_general',
        'hopital_de_district',
        'chu',
        'cma',
        'csi',
        'clinique_privee',
        'pharmacie',
        'laboratoire',
        'centre_specialise',
      ]
    },
    { key: 'adresse', label: 'Adresse', type: 'text' },
    { key: 'ville', label: 'Ville', type: 'text' },
    {
      key: 'region',
      label: 'Région',
      type: 'select',
      options: [
        'Adamaoua', 'Centre', 'Est', 'Extrême-Nord', 'Littoral',
        'Nord', 'Nord-Ouest', 'Ouest', 'Sud', 'Sud-Ouest',
      ]
    },
    { key: 'telephone', label: 'Téléphone', type: 'text' },
    { key: 'latitude', label: 'Latitude', type: 'number' },
    { key: 'longitude', label: 'Longitude', type: 'number' },
    { key: 'horaires', label: 'Horaires', type: 'textarea' },
    { key: 'specialites', label: 'Spécialités', type: 'textarea' },
    { key: 'services', label: 'Services', type: 'textarea' },
    { key: 'description', label: 'Description', type: 'textarea' },
    { key: 'estActif', label: 'Actif', type: 'checkbox' },
    { key: 'urgences24h', label: 'Urgences 24h', type: 'checkbox' },
  ]

  return (
    <div id="admin-centres" className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display font-bold text-xl text-primary-900 dark:text-sable">
          Centres de Santé
        </h1>
        <p className="text-sm text-primary-300/70 mt-0.5 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5" strokeWidth={1.5} />
          Gérez les centres de santé référencés sur la plateforme
        </p>
      </div>
      <CrudTable
        endpoint="/api/centre_de_santes"
        fields={fields}
        title="Centres de Santé"
      />
    </div>
  )
}
