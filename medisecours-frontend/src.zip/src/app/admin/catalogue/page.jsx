'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { BookOpen, Layers, Heart } from 'lucide-react'
import CrudTable from '../../../components/admin/CrudTable'

const tabs = [
  { key: 'categories', label: 'Catégories', icon: Layers },
  { key: 'maladies', label: 'Maladies', icon: Heart },
  { key: 'premiers-soins', label: 'Premiers Soins', icon: BookOpen },
]

const categoriesFields = [
  { key: 'nom', label: 'Nom', type: 'text' },
  { key: 'couleur', label: 'Couleur', type: 'color' },
  { key: 'description', label: 'Description', type: 'textarea' },
]

const maladiesFields = [
  { key: 'nom', label: 'Nom', type: 'text' },
  {
    key: 'niveauGravite',
    label: 'Niveau de Gravité',
    type: 'select',
    options: ['LÉGÈRE', 'MODÉRÉE', 'SÉVÈRE', 'CRITIQUE', 'VARIABLE'],
  },
  { key: 'urgence', label: 'Urgence', type: 'checkbox' },
  { key: 'contagieux', label: 'Contagieux', type: 'checkbox' },
  { key: 'description', label: 'Description', type: 'textarea' },
  { key: 'symptomes', label: 'Symptômes', type: 'textarea' },
  { key: 'causes', label: 'Causes', type: 'textarea' },
  { key: 'precautions', label: 'Précautions', type: 'textarea' },
  { key: 'traitement', label: 'Traitement', type: 'textarea' },
]

const premiersSoinsFields = [
  { key: 'titre', label: 'Titre', type: 'text' },
  {
    key: 'niveauUrgence',
    label: "Niveau d'Urgence",
    type: 'select',
    options: ['FAIBLE', 'MOYEN', 'ÉLEVÉ', 'CRITIQUE'],
  },
  { key: 'description', label: 'Description', type: 'textarea' },
  { key: 'symptomes', label: 'Symptômes', type: 'textarea' },
]

export default function CataloguePage() {
  const [activeTab, setActiveTab] = useState('categories')

  return (
    <div id="admin-catalogue" className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display font-bold text-xl text-primary-900 dark:text-sable">
          Catalogue Médical
        </h1>
        <p className="text-sm text-primary-300/70 mt-0.5">
          Gérez le contenu médical : catégories, maladies et protocoles de premiers soins
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
        {tabs.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            id={`catalogue-tab-${key}`}
            onClick={() => setActiveTab(key)}
            className={`inline-flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-semibold whitespace-nowrap transition-all duration-200 ${
              activeTab === key
                ? 'bg-primary-900 dark:bg-mint-500 text-white shadow-lg shadow-primary-900/20 dark:shadow-mint-500/20'
                : 'bg-white dark:bg-primary-800 text-primary-600 dark:text-sable/70 border border-primary-100/60 dark:border-white/10 hover:border-primary-300/40 hover:text-primary-900'
            }`}
          >
            <Icon className="w-4 h-4" strokeWidth={1.8} />
            {label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        {activeTab === 'categories' && (
          <CrudTable endpoint="/api/categories" fields={categoriesFields} title="Catégories de Maladies" />
        )}
        {activeTab === 'maladies' && (
          <CrudTable endpoint="/api/maladies" fields={maladiesFields} title="Maladies" />
        )}
        {activeTab === 'premiers-soins' && (
          <CrudTable endpoint="/api/premier_soins" fields={premiersSoinsFields} title="Protocoles de Premiers Soins" />
        )}
      </motion.div>
    </div>
  )
}
