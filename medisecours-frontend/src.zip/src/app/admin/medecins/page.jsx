'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  CheckCircle,
  XCircle,
  Mail,
  Phone,
  Calendar,
  Shield,
  Stethoscope,
  PartyPopper,
  Clock,
  FileCheck,
  AlertTriangle,
  ExternalLink,
  MessageSquare,
} from 'lucide-react'
import api from '../../../api/axios'
import LoadingSpinner from '../../../components/ui/LoadingSpinner'
import EmptyState from '../../../components/ui/EmptyState'
import { useToast } from '../../../components/ui/Toast'

export default function MedecinsValidationPage() {
  const [doctors, setDoctors] = useState([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(null)
  const toast = useToast()

  const loadDoctors = () => {
    setLoading(true)
    api.get('/api/admin/medecins/en-attente')
      .then((res) => setDoctors(res.data.medecins || []))
      .catch(() => toast.error('Impossible de charger les médecins en attente'))
      .finally(() => setLoading(false))
  }

  useEffect(loadDoctors, [])

  const handleValidation = async (doctorId, estValide) => {
    setActionLoading(doctorId)
    try {
      await api.patch(`/api/admin/medecins/${doctorId}/validation`, { estValide })
      toast.success(estValide ? 'Médecin validé avec succès' : 'Validation refusée')
      setDoctors((prev) => prev.filter((d) => d.id !== doctorId))
    } catch {
      toast.error('Erreur lors de la validation')
    } finally {
      setActionLoading(null)
    }
  }

  const getInitials = (doctor) => {
    const first = doctor.prenom?.[0] || doctor.nom?.[0] || 'D'
    const last = doctor.nom?.[0] || ''
    return (first + last).toUpperCase()
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  const daysAgo = (dateString) => {
    if (!dateString) return ''
    const diff = Date.now() - new Date(dateString).getTime()
    const days = Math.floor(diff / 86400000)
    if (days === 0) return "aujourd'hui"
    if (days === 1) return 'hier'
    return `il y a ${days} jours`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <LoadingSpinner label="Chargement des médecins..." />
      </div>
    )
  }

  if (doctors.length === 0) {
    return (
      <div id="admin-medecins-empty" className="max-w-lg mx-auto">
        <EmptyState
          icon={PartyPopper}
          title="Tout est en ordre !"
          description="Aucun médecin en attente de validation pour le moment. Vous serez notifié dès qu'une nouvelle inscription sera effectuée."
        />
      </div>
    )
  }

  return (
    <div id="admin-medecins" className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-xl text-primary-900 dark:text-sable">
            Validation des médecins
          </h1>
          <p className="text-sm text-primary-300/70 mt-0.5">
            Vérifiez les informations et approuvez les nouvelles inscriptions
          </p>
        </div>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-urgence-500/10 to-urgence-500/5 border border-urgence-500/20 text-urgence-700 dark:text-urgence-400 text-sm font-semibold">
          <AlertTriangle className="w-4 h-4" strokeWidth={2} />
          {doctors.length} médecin{doctors.length > 1 ? 's' : ''} en attente
        </div>
      </div>

      {/* Cards grid */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {doctors.map((doctor, index) => (
            <motion.div
              key={doctor.id}
              id={`doctor-card-${doctor.id}`}
              layout
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.85, y: -20 }}
              transition={{ delay: index * 0.04, duration: 0.3, ease: 'easeOut' }}
              className="group relative rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden"
            >
              {/* Left accent gradient */}
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-mint-500 via-mint-400 to-mint-500/50 opacity-60" />

              {/* Top gradient decoration */}
              <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-mint-500/[0.04] to-transparent pointer-events-none" />
              <div className="absolute -right-10 -top-10 w-28 h-28 rounded-full bg-mint-500/[0.06] blur-xl pointer-events-none" />

              {/* Card content */}
              <div className="relative p-6">
                {/* Avatar + Name */}
                <div className="flex flex-col items-center text-center mb-5">
                  <div className="relative mb-3">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-mint-500 to-mint-600 flex items-center justify-center text-white font-bold text-xl shadow-md shadow-mint-500/20">
                      {getInitials(doctor)}
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-400 border-2 border-white dark:border-primary-800 flex items-center justify-center">
                      <Clock className="w-2.5 h-2.5 text-white" strokeWidth={3} />
                    </div>
                  </div>
                  <h3 className="font-display font-bold text-lg text-primary-900 dark:text-sable">
                    Dr. {doctor.prenom} {doctor.nom}
                  </h3>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-mint-500/10 text-mint-600 dark:text-mint-400 text-xs font-semibold mt-1">
                    <Stethoscope className="w-3 h-3" strokeWidth={2.5} />
                    {doctor.specialite}
                  </div>
                  {doctor.createdAt && (
                    <p className="text-[10px] text-primary-300/50 mt-1.5 font-medium">
                      Inscrit {daysAgo(doctor.createdAt)}
                    </p>
                  )}
                </div>

                {/* Info rows */}
                <div className="space-y-2.5 mb-6">
                  <div className="flex items-center gap-3 p-2.5 rounded-xl bg-primary-50/50 dark:bg-white/[0.02] border border-primary-100/30 dark:border-white/5">
                    <div className="w-8 h-8 rounded-lg bg-primary-100/50 dark:bg-white/5 flex items-center justify-center shrink-0">
                      <Shield className="w-4 h-4 text-primary-400" strokeWidth={1.5} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] font-semibold text-primary-300/70 uppercase tracking-wider">N° d'Ordre</p>
                      <p className="text-sm font-medium text-primary-900 dark:text-sable truncate">{doctor.numeroOrdre}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-2.5 rounded-xl bg-primary-50/50 dark:bg-white/[0.02] border border-primary-100/30 dark:border-white/5">
                    <div className="w-8 h-8 rounded-lg bg-primary-100/50 dark:bg-white/5 flex items-center justify-center shrink-0">
                      <Mail className="w-4 h-4 text-primary-400" strokeWidth={1.5} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] font-semibold text-primary-300/70 uppercase tracking-wider">Email</p>
                      <p className="text-sm font-medium text-primary-900 dark:text-sable truncate">{doctor.email}</p>
                    </div>
                    <button
                      id={`email-doctor-${doctor.id}`}
                      className="w-7 h-7 rounded-lg bg-mint-500/10 hover:bg-mint-500/20 text-mint-500 flex items-center justify-center shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Envoyer un email"
                    >
                      <MessageSquare className="w-3.5 h-3.5" strokeWidth={2} />
                    </button>
                  </div>

                  {doctor.telephone && (
                    <div className="flex items-center gap-3 p-2.5 rounded-xl bg-primary-50/50 dark:bg-white/[0.02] border border-primary-100/30 dark:border-white/5">
                      <div className="w-8 h-8 rounded-lg bg-primary-100/50 dark:bg-white/5 flex items-center justify-center shrink-0">
                        <Phone className="w-4 h-4 text-primary-400" strokeWidth={1.5} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] font-semibold text-primary-300/70 uppercase tracking-wider">Téléphone</p>
                        <p className="text-sm font-medium text-primary-900 dark:text-sable">{doctor.telephone}</p>
                      </div>
                      <button
                        id={`phone-doctor-${doctor.id}`}
                        className="w-7 h-7 rounded-lg bg-mint-500/10 hover:bg-mint-500/20 text-mint-500 flex items-center justify-center shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Appeler"
                      >
                        <Phone className="w-3.5 h-3.5" strokeWidth={2} />
                      </button>
                    </div>
                  )}

                  <div className="flex items-center gap-3 p-2.5 rounded-xl bg-primary-50/50 dark:bg-white/[0.02] border border-primary-100/30 dark:border-white/5">
                    <div className="w-8 h-8 rounded-lg bg-primary-100/50 dark:bg-white/5 flex items-center justify-center shrink-0">
                      <Calendar className="w-4 h-4 text-primary-400" strokeWidth={1.5} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] font-semibold text-primary-300/70 uppercase tracking-wider">Inscription</p>
                      <p className="text-sm font-medium text-primary-900 dark:text-sable">{formatDate(doctor.createdAt)}</p>
                    </div>
                  </div>
                </div>

                {/* Status badges */}
                <div className="flex flex-wrap gap-2 mb-5">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-900/10 text-amber-700 dark:text-amber-400 text-[10px] font-semibold border border-amber-200/50 dark:border-amber-900/20">
                    <Clock className="w-3 h-3" strokeWidth={2.5} />
                    Validation en attente
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-primary-50 dark:bg-white/5 text-primary-400 text-[10px] font-semibold border border-primary-100/50 dark:border-white/10">
                    <FileCheck className="w-3 h-3" strokeWidth={2.5} />
                    Documents fournis
                  </span>
                </div>

                {/* Action buttons */}
                <div className="flex gap-2">
                  <button
                    id={`approve-doctor-${doctor.id}`}
                    onClick={() => handleValidation(doctor.id, true)}
                    disabled={actionLoading === doctor.id}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-mint-500 to-mint-600 hover:from-mint-600 hover:to-mint-700 text-white font-semibold text-sm shadow-lg shadow-mint-500/20 hover:shadow-mint-500/30 transition-all duration-200 disabled:opacity-50"
                  >
                    {actionLoading === doctor.id ? (
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <CheckCircle className="w-4 h-4" strokeWidth={2.5} />
                    )}
                    Approuver
                  </button>
                  <button
                    id={`reject-doctor-${doctor.id}`}
                    onClick={() => handleValidation(doctor.id, false)}
                    disabled={actionLoading === doctor.id}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-urgence-500 to-urgence-600 hover:from-urgence-600 hover:to-urgence-700 text-white font-semibold text-sm shadow-lg shadow-urgence-500/20 hover:shadow-urgence-500/30 transition-all duration-200 disabled:opacity-50"
                  >
                    <XCircle className="w-4 h-4" strokeWidth={2.5} />
                    Rejeter
                  </button>
                </div>

                <button
                  id={`request-info-${doctor.id}`}
                  disabled={actionLoading === doctor.id}
                  className="w-full mt-2 inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-primary-200 dark:border-white/10 text-primary-600 dark:text-sable/70 hover:bg-primary-50 dark:hover:bg-white/[0.03] text-sm font-medium transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5" strokeWidth={1.8} />
                  Demander plus d'informations
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}
