'use client'

import { useEffect, useState } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard,
  Users,
  Stethoscope,
  Hospital,
  BookOpen,
  Star,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  ArrowLeftFromLine,
  HeartPulse,
  Bell,
} from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'
import LoadingSpinner from '../../components/ui/LoadingSpinner'

const navigation = [
  { name: "Vue d'ensemble", href: '/admin', icon: LayoutDashboard },
  { name: 'Utilisateurs', href: '/admin/utilisateurs', icon: Users },
  { name: 'Validation Médecins', href: '/admin/medecins', icon: Stethoscope },
  { name: 'Centres de Santé', href: '/admin/centres', icon: Hospital },
  { name: 'Catalogue Médical', href: '/admin/catalogue', icon: BookOpen },
  { name: 'Avis & Modération', href: '/admin/avis', icon: Star },
  { name: 'Paramètres', href: '/admin/parametres', icon: Settings },
]

export default function AdminLayout({ children }) {
  const { isAdmin, mounted, user, logout } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    if (mounted && !isAdmin) {
      router.replace('/login?from=/admin')
    }
  }, [mounted, isAdmin, router])

  if (!mounted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-900 via-primary-900 to-primary-700 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-mint-500 to-mint-600 flex items-center justify-center shadow-lg shadow-mint-500/20 animate-pulse">
            <HeartPulse className="w-8 h-8 text-white" />
          </div>
          <LoadingSpinner label="Chargement du dashboard..." />
        </div>
      </div>
    )
  }

  if (!isAdmin) return null

  const getPageTitle = () => {
    const route = navigation.find((item) => item.href === pathname)
    return route?.name || 'Administration'
  }

  const getBreadcrumbs = () => {
    const crumbs = [{ name: 'Administration', href: '/admin' }]
    if (pathname !== '/admin') {
      const route = navigation.find((item) => item.href === pathname)
      if (route) crumbs.push({ name: route.name, href: route.href })
    }
    return crumbs
  }

  const getInitials = () => {
    if (!user) return 'A'
    const first = user.prenom?.[0] || user.nom?.[0] || user.email?.[0] || 'A'
    const last = user.nom?.[0] || ''
    return (first + last).toUpperCase()
  }

  const renderSidebar = (mobile = false) => (
    <aside
      id={mobile ? 'admin-sidebar-mobile' : 'admin-sidebar-desktop'}
      className={`${
        mobile
          ? 'fixed top-0 left-0 h-screen w-72 z-50'
          : 'hidden md:flex fixed md:sticky top-0 left-0 h-screen w-72 z-50'
      } flex-col bg-gradient-to-b from-primary-900 via-primary-900 to-primary-700 border-r border-white/5`}
    >
      {/* Dot grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.5) 1px, transparent 0)',
          backgroundSize: '20px 20px',
        }}
      />

      {/* Decorative gradient blobs */}
      <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-mint-500/5 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-80 h-80 rounded-full bg-primary-500/10 blur-3xl pointer-events-none" />

      {/* Logo */}
      <div className="relative p-6 border-b border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-mint-500 to-mint-700 flex items-center justify-center shadow-lg shadow-mint-500/20 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-mint-700/30 to-transparent" />
              <HeartPulse className="w-6 h-6 text-white relative z-10" />
            </div>
            <div>
              <h1 className="font-display font-bold text-white text-lg tracking-tight">MediSecours+</h1>
              <p className="text-[11px] text-primary-300/80 font-medium">Espace Administration</p>
            </div>
          </div>
          {mobile && (
            <button
              id="admin-sidebar-close"
              onClick={() => setSidebarOpen(false)}
              className="text-primary-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="relative flex-1 p-3 space-y-0.5 overflow-y-auto">
        {navigation.map((item) => {
          const isActive = pathname === item.href
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              id={`admin-nav-${mobile ? 'mobile-' : ''}${item.href.replace(/\//g, '-') || 'dashboard'}`}
              href={item.href}
              onClick={() => mobile && setSidebarOpen(false)}
              className={`group relative flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-gradient-to-r from-mint-500/15 to-mint-500/5 text-mint-500 shadow-sm shadow-mint-500/5'
                  : 'text-primary-300/80 hover:bg-white/[0.04] hover:text-white'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeNavIndicator"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-r-full bg-gradient-to-b from-mint-500 to-mint-400 shadow-sm shadow-mint-500/40"
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                />
              )}
              <div
                className={`relative flex items-center justify-center w-8 h-8 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-mint-500/20 text-mint-500'
                    : 'bg-white/[0.03] text-primary-300/60 group-hover:bg-white/[0.06] group-hover:text-white'
                }`}
              >
                <Icon className="w-4.5 h-4.5" strokeWidth={1.8} />
              </div>
              <span className="flex-1">{item.name}</span>
              {isActive && <ChevronRight className="w-3.5 h-3.5 text-mint-500/60" strokeWidth={2} />}
            </Link>
          )
        })}
      </nav>

      {/* User profile */}
      <div className="relative p-4 border-t border-white/5">
        <div className="flex items-center gap-3 mb-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-mint-500 to-mint-700 flex items-center justify-center text-white font-bold text-sm shadow-sm">
              {getInitials()}
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-mint-500 border-2 border-primary-900 flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate">
              {user?.prenom || user?.nom || 'Admin'}
            </p>
            <p className="text-[11px] text-primary-300/60 truncate">{user?.email}</p>
          </div>
        </div>
        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-semibold tracking-wide uppercase bg-mint-500/10 text-mint-400 mb-2.5">
          ROLE_ADMIN
        </span>
        <button
          id={`admin-logout-${mobile ? 'mobile' : 'desktop'}`}
          onClick={logout}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-white/[0.04] hover:bg-urgence-500/15 text-primary-300/70 hover:text-urgence-400 text-sm font-medium transition-all duration-200 group"
        >
          <LogOut className="w-4 h-4 transition-transform duration-200 group-hover:-translate-x-0.5" />
          Déconnexion
        </button>
      </div>
    </aside>
  )

  return (
    <div className="min-h-screen bg-primary-50/60 dark:bg-primary-900/60 flex">
      {/* Mobile backdrop */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            id="admin-sidebar-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar - desktop */}
      {renderSidebar(false)}

      {/* Sidebar - mobile */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'tween', duration: 0.25, ease: 'easeOut' }}
            className="md:hidden fixed inset-0 z-50"
          >
            {renderSidebar(true)}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Gradient border separator */}
      <div className="hidden md:block w-px bg-gradient-to-b from-mint-500/20 via-white/5 to-mint-500/10 shrink-0" />

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-h-screen w-0">
        {/* Top bar */}
        <header
          id="admin-topbar"
          className="sticky top-0 z-30 bg-white/80 dark:bg-primary-800/80 backdrop-blur-xl border-b border-primary-100/50 dark:border-white/5"
        >
          <div className="px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                id="admin-sidebar-toggle"
                onClick={() => setSidebarOpen(true)}
                className="md:hidden w-9 h-9 flex items-center justify-center rounded-xl text-primary-500 dark:text-sable hover:bg-primary-100 dark:hover:bg-primary-700/50 transition-colors"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div>
                <h2 className="font-display font-bold text-xl text-primary-900 dark:text-sable">
                  {getPageTitle()}
                </h2>
                {/* Breadcrumbs */}
                <nav className="flex items-center gap-1.5 mt-0.5">
                  {getBreadcrumbs().map((crumb, i) => (
                    <span key={crumb.href} className="flex items-center gap-1.5">
                      {i > 0 && (
                        <ChevronRight className="w-3 h-3 text-primary-200 dark:text-primary-500" strokeWidth={2} />
                      )}
                      {i === getBreadcrumbs().length - 1 ? (
                        <span className="text-xs text-primary-400 font-semibold">{crumb.name}</span>
                      ) : (
                        <Link
                          href={crumb.href}
                          className="text-xs text-primary-300/70 hover:text-primary-500 dark:hover:text-sable transition-colors"
                        >
                          {crumb.name}
                        </Link>
                      )}
                    </span>
                  ))}
                </nav>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Notification bell */}
              <button
                id="admin-notifications"
                className="relative w-9 h-9 flex items-center justify-center rounded-xl text-primary-300 hover:text-primary-500 dark:hover:text-sable hover:bg-primary-100 dark:hover:bg-primary-700/50 transition-all"
              >
                <Bell className="w-4.5 h-4.5" strokeWidth={1.6} />
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-urgence-500 ring-2 ring-white dark:ring-primary-800" />
              </button>

              <Link
                href="/"
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-primary-300 hover:text-primary-500 dark:hover:text-sable hover:bg-primary-100 dark:hover:bg-primary-700/50 transition-all"
              >
                <ArrowLeftFromLine className="w-3.5 h-3.5" />
                Retour au site
              </Link>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main id="admin-content" className="flex-1 p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  )
}
