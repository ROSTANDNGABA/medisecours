'use client'

import { useEffect, useState, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, X, User, Stethoscope, Shield, Phone, Mail, Calendar, ChevronRight, BadgeCheck, Clock } from 'lucide-react'
import api from '../../../api/axios'
import LoadingSpinner from '../../../components/ui/LoadingSpinner'
import EmptyState from '../../../components/ui/EmptyState'
import { useToast } from '../../../components/ui/Toast'

const roleBadgeStyles = {
  primary: 'bg-primary-500/10 text-primary-500',
  mint: 'bg-mint-500/10 text-mint-500',
  urgence: 'bg-urgence-500/10 text-urgence-500',
}

const roleAvatarStyles = {
  primary: 'bg-gradient-to-br from-primary-500 to-primary-600',
  mint: 'bg-gradient-to-br from-mint-500 to-mint-600',
  urgence: 'bg-gradient-to-br from-urgence-500 to-urgence-600',
}

function formatDate(dateString) {
  if (!dateString) return 'N/A'
  return new Date(dateString).toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

function timeAgo(dateString) {
  if (!dateString) return ''
  const diff = Date.now() - new Date(dateString).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'à l\'instant'
  if (mins < 60) return `il y a ${mins} min`
  if (mins < 1440) return `il y a ${Math.floor(mins / 60)}h`
  const days = Math.floor(mins / 1440)
  if (days === 1) return 'hier'
  return `il y a ${days} jours`
}

export default function UtilisateursPage() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('ALL')
  const [selectedUser, setSelectedUser] = useState(null)
  const toast = useToast()

  useEffect(() => {
    api.get('/api/users')
      .then((res) => {
        const data = res.data['hydra:member'] || res.data.member || res.data
        setUsers(Array.isArray(data) ? data : [])
      })
      .catch(() => toast.error('Impossible de charger les utilisateurs'))
      .finally(() => setLoading(false))
  }, [])

  const filtered = useMemo(() => {
    return users.filter((u) => {
      const matchSearch =
        search === '' ||
        u.nom?.toLowerCase().includes(search.toLowerCase()) ||
        u.prenom?.toLowerCase().includes(search.toLowerCase()) ||
        u.email?.toLowerCase().includes(search.toLowerCase())

      const matchRole =
        roleFilter === 'ALL' ||
        (roleFilter === 'ADMIN' && u.roles?.includes('ROLE_ADMIN')) ||
        (roleFilter === 'MEDECIN' && u.roles?.includes('ROLE_MEDECIN')) ||
        (roleFilter === 'PATIENT' && u.roles?.includes('ROLE_PATIENT'))

      return matchSearch && matchRole
    })
  }, [users, search, roleFilter])

  const getRoleBadge = (user) => {
    if (user.roles?.includes('ROLE_ADMIN')) return { label: 'Admin', color: 'urgence' }
    if (user.roles?.includes('ROLE_MEDECIN')) return { label: 'Médecin', color: 'mint' }
    return { label: 'Patient', color: 'primary' }
  }

  const getInitials = (user) => {
    const first = user.prenom?.[0] || user.nom?.[0] || user.email?.[0] || 'U'
    const last = user.nom?.[0] || ''
    return (first + last).toUpperCase()
  }

  const roleCounts = {
    ALL: users.length,
    PATIENT: users.filter((u) => u.roles?.includes('ROLE_PATIENT')).length,
    MEDECIN: users.filter((u) => u.roles?.includes('ROLE_MEDECIN')).length,
    ADMIN: users.filter((u) => u.roles?.includes('ROLE_ADMIN')).length,
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <LoadingSpinner label="Chargement des utilisateurs..." />
      </div>
    )
  }

  return (
    <div id="admin-utilisateurs" className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display font-bold text-xl text-primary-900 dark:text-sable">
          Gestion des utilisateurs
        </h1>
        <p className="text-sm text-primary-300/70 mt-0.5">
          {users.length} utilisateur{users.length > 1 ? 's' : ''} inscrit{users.length > 1 ? 's' : ''} sur la plateforme
        </p>
      </div>

      {/* Search + Filters */}
      <div className="mb-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-primary-300" strokeWidth={1.8} />
          <input
            id="user-search"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher par nom, prénom ou email..."
            className="w-full pl-11 pr-4 py-3 rounded-xl border border-primary-100/60 dark:border-white/10 bg-white dark:bg-primary-800 focus:outline-none focus:ring-2 focus:ring-mint-500/40 focus:border-mint-500 transition-all text-sm"
          />
          {search && (
            <button
              id="clear-user-search"
              onClick={() => setSearch('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-primary-300 hover:text-primary-500"
            >
              <X className="w-4 h-4" strokeWidth={2} />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {[
            { key: 'ALL', label: 'Tous', icon: User },
            { key: 'PATIENT', label: 'Patients', icon: User },
            { key: 'MEDECIN', label: 'Médecins', icon: Stethoscope },
            { key: 'ADMIN', label: 'Admins', icon: Shield },
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              id={`filter-role-${key}`}
              onClick={() => setRoleFilter(key)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all duration-200 ${
                roleFilter === key
                  ? 'bg-primary-900 dark:bg-mint-500 text-white shadow-lg shadow-primary-900/20 dark:shadow-mint-500/20'
                  : 'bg-white dark:bg-primary-800 text-primary-600 dark:text-sable/70 border border-primary-100/60 dark:border-white/10 hover:border-primary-300/40 hover:text-primary-900'
              }`}
            >
              <Icon className="w-4 h-4" strokeWidth={1.8} />
              {label}
              <span className={`ml-0.5 text-xs ${roleFilter === key ? 'text-white/70' : 'text-primary-300'}`}>
                {roleCounts[key]}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <EmptyState
          title="Aucun utilisateur trouvé"
          description="Essayez de modifier vos critères de recherche."
        />
      ) : (
        <div className="rounded-2xl border border-primary-100/60 dark:border-white/5 bg-white dark:bg-primary-800 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-primary-50/80 dark:bg-white/[0.02] sticky top-0 z-10">
                  <th className="text-left px-6 py-4 font-semibold text-xs text-primary-400 uppercase tracking-wider">Utilisateur</th>
                  <th className="text-left px-6 py-4 font-semibold text-xs text-primary-400 uppercase tracking-wider">Email</th>
                  <th className="text-left px-6 py-4 font-semibold text-xs text-primary-400 uppercase tracking-wider">Rôle</th>
                  <th className="text-left px-6 py-4 font-semibold text-xs text-primary-400 uppercase tracking-wider">Téléphone</th>
                  <th className="text-left px-6 py-4 font-semibold text-xs text-primary-400 uppercase tracking-wider">Inscription</th>
                  <th className="px-6 py-4" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((user, index) => {
                  const role = getRoleBadge(user)
                  return (
                    <motion.tr
                      key={user.id}
                      id={`user-row-${user.id}`}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.015 }}
                      onClick={() => setSelectedUser(user)}
                      className={`border-t border-primary-100/30 dark:border-white/5 hover:bg-primary-50/50 dark:hover:bg-white/[0.02] cursor-pointer transition-colors ${
                        index % 2 === 0 ? 'bg-white dark:bg-transparent' : 'bg-primary-50/20 dark:bg-white/[0.01]'
                      }`}
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-full ${roleAvatarStyles[role.color]} flex items-center justify-center text-white font-bold text-sm shadow-sm shrink-0`}>
                            {getInitials(user)}
                          </div>
                          <div>
                            <p className="font-semibold text-sm text-primary-900 dark:text-sable">
                              {user.prenom} {user.nom}
                            </p>
                            {user.createdAt && (
                              <p className="text-[10px] text-primary-300/50 mt-0.5">
                                {timeAgo(user.createdAt)}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-primary-500 dark:text-primary-300">
                        {user.email}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${roleBadgeStyles[role.color]}`}>
                          {role.label === 'Médecin' && <Stethoscope className="w-3 h-3" strokeWidth={2.5} />}
                          {role.label === 'Admin' && <Shield className="w-3 h-3" strokeWidth={2.5} />}
                          {role.label === 'Patient' && <User className="w-3 h-3" strokeWidth={2.5} />}
                          {role.label}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-primary-500 dark:text-primary-300">
                        {user.telephone || <span className="text-primary-200 dark:text-primary-500">&mdash;</span>}
                      </td>
                      <td className="px-6 py-4 text-sm text-primary-500 dark:text-primary-300 whitespace-nowrap">
                        <span className="hidden lg:inline">{formatDate(user.createdAt)}</span>
                        <span className="lg:hidden">{timeAgo(user.createdAt)}</span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <ChevronRight className="w-4 h-4 text-primary-200 transition-colors" strokeWidth={1.8} />
                      </td>
                    </motion.tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* User detail slide-over */}
      <AnimatePresence>
        {selectedUser && (
          <>
            <motion.div
              id="user-detail-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedUser(null)}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            />
            <motion.div
              id="user-detail-panel"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 h-full w-full max-w-lg bg-white dark:bg-primary-800 shadow-2xl z-50 overflow-y-auto"
            >
              <div className="p-6 lg:p-8">
                {/* Close */}
                <div className="flex items-start justify-between mb-8">
                  <h3 className="font-display font-bold text-xl text-primary-900 dark:text-sable">
                    Détails de l'utilisateur
                  </h3>
                  <button
                    id="close-user-detail"
                    onClick={() => setSelectedUser(null)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg text-primary-300 hover:text-primary-700 hover:bg-primary-100 dark:hover:bg-primary-700 transition-colors"
                  >
                    <X className="w-4.5 h-4.5" strokeWidth={2} />
                  </button>
                </div>

                {/* Avatar + Name */}
                <div className="flex flex-col items-center text-center mb-8">
                  <div className={`w-20 h-20 rounded-full ${roleAvatarStyles[getRoleBadge(selectedUser).color]} flex items-center justify-center text-white font-bold text-2xl mb-4 shadow-md`}>
                    {getInitials(selectedUser)}
                  </div>
                  <h4 className="font-display font-semibold text-xl text-primary-900 dark:text-sable">
                    {selectedUser.prenom} {selectedUser.nom}
                  </h4>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${roleBadgeStyles[getRoleBadge(selectedUser).color]}`}>
                      {getRoleBadge(selectedUser).label === 'Médecin' && <Stethoscope className="w-3 h-3" strokeWidth={2.5} />}
                      {getRoleBadge(selectedUser).label}
                    </span>
                    {selectedUser.createdAt && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-primary-100/50 dark:bg-white/5 text-primary-400">
                        <Clock className="w-3 h-3" strokeWidth={2} />
                        {timeAgo(selectedUser.createdAt)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Details cards */}
                <div className="space-y-3">
                  <DetailCard icon={Mail} label="Email" value={selectedUser.email} />
                  {selectedUser.telephone && <DetailCard icon={Phone} label="Téléphone" value={selectedUser.telephone} />}
                  <DetailCard icon={Calendar} label="Inscription" value={formatDate(selectedUser.createdAt)} />

                  {/* Doctor-specific */}
                  {selectedUser.roles?.includes('ROLE_MEDECIN') && (
                    <>
                      <div className="pt-3 pb-1">
                        <p className="text-xs font-bold text-mint-500 uppercase tracking-wider flex items-center gap-1.5">
                          <Stethoscope className="w-3.5 h-3.5" strokeWidth={2.5} />
                          Informations médicales
                        </p>
                      </div>
                      {selectedUser.specialite && (
                        <DetailCard icon={Stethoscope} label="Spécialité" value={selectedUser.specialite} accent="mint" />
                      )}
                      {selectedUser.numeroOrdre && (
                        <DetailCard icon={Shield} label="Numéro d'Ordre" value={selectedUser.numeroOrdre} accent="mint" />
                      )}
                      <DetailCard
                        icon={BadgeCheck}
                        label="Statut de Validation"
                        value={selectedUser.estValide ? 'Validé' : 'En attente'}
                        accent="mint"
                      />
                    </>
                  )}

                  {/* Patient-specific */}
                  {selectedUser.roles?.includes('ROLE_PATIENT') && (
                    <>
                      <div className="pt-3 pb-1">
                        <p className="text-xs font-bold text-urgence-500 uppercase tracking-wider flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5" strokeWidth={2.5} />
                          Informations patient
                        </p>
                      </div>
                      {selectedUser.groupeSanguin && (
                        <DetailCard icon={User} label="Groupe Sanguin" value={selectedUser.groupeSanguin} accent="urgence" />
                      )}
                      {selectedUser.allergies && (
                        <DetailCard icon={User} label="Allergies" value={selectedUser.allergies} accent="urgence" />
                      )}
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}

function DetailCard({ icon: Icon, label, value, accent = 'primary' }) {
  const accentBg = {
    primary: 'bg-primary-50 dark:bg-primary-900/40',
    mint: 'bg-mint-50/50 dark:bg-mint-900/10',
    urgence: 'bg-urgence-50/50 dark:bg-urgence-900/10',
  }
  const accentIcon = {
    primary: 'text-primary-300',
    mint: 'text-mint-500',
    urgence: 'text-urgence-500',
  }
  const accentLabel = {
    primary: 'text-primary-300',
    mint: 'text-mint-500',
    urgence: 'text-urgence-500',
  }

  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl ${accentBg[accent]}`}>
      <Icon className={`w-5 h-5 ${accentIcon[accent]} shrink-0 mt-0.5`} strokeWidth={1.5} />
      <div className="flex-1 min-w-0">
        <p className={`text-[10px] font-bold ${accentLabel[accent]} uppercase tracking-wider`}>{label}</p>
        <p className="text-sm font-medium text-primary-900 dark:text-sable mt-0.5 break-words">{value || '—'}</p>
      </div>
    </div>
  )
}
