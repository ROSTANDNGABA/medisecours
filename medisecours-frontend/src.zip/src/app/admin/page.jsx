'use client'

import { useEffect, useState, useCallback } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import {
  Users,
  Stethoscope,
  Hospital,
  Activity,
  BookOpen,
  MessageSquare,
  Star,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  CheckCircle,
  XCircle,
  Clock,
  ShieldCheck,
  ArrowRight,
  RefreshCw,
  UserCheck,
  UserPlus,
  Calendar,
} from 'lucide-react'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import api from '../../api/axios'
import LoadingSpinner from '../../components/ui/LoadingSpinner'
import { useToast } from '../../components/ui/Toast'

const kpiAccentBar = {
  primary: 'bg-primary-500',
  mint: 'bg-mint-500',
  urgence: 'bg-urgence-500',
}

const kpiIconGradient = {
  primary: 'from-primary-500/20 to-primary-500/5',
  mint: 'from-mint-500/20 to-mint-500/5',
  urgence: 'from-urgence-500/20 to-urgence-500/5',
}

const kpiIconColor = {
  primary: 'text-primary-500',
  mint: 'text-mint-500',
  urgence: 'text-urgence-500',
}

const kpiTrends = {
  'kpi-total-users': { value: '+12%', up: true },
  'kpi-active-doctors': { value: '+8%', up: true },
  'kpi-pending-validations': { value: '+3', up: false },
  'kpi-active-centers': { value: '+5%', up: true },
}

const recentActivity = [
  { id: 1, type: 'inscription', user: 'Dr. Jean Mbarga', detail: 'Nouvelle inscription médecin', timeOffset: 15 },
  { id: 2, type: 'validation', user: 'Dr. Alice Ngo', detail: 'Validation approuvée', timeOffset: 45 },
  { id: 3, type: 'signalement', user: 'Paul Biya', detail: 'Avis signalé comme inapproprié', timeOffset: 120 },
  { id: 4, type: 'centre', user: 'Admin', detail: 'Nouveau centre : CMA Yaoundé', timeOffset: 180 },
]

function AnimatedNumber({ value }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    let start = 0
    const duration = 800
    const step = Math.ceil(value / (duration / 16))
    const timer = setInterval(() => {
      start += step
      if (start >= value) {
        setDisplay(value)
        clearInterval(timer)
      } else {
        setDisplay(start)
      }
    }, 16)
    return () => clearInterval(timer)
  }, [value])
  return <>{display}</>
}

function TimeAgo({ minutes }) {
  if (minutes < 1) return 'à l\'instant'
  if (minutes < 60) return `il y a ${minutes} min`
  if (minutes < 1440) return `il y a ${Math.floor(minutes / 60)}h`
  return `il y a ${Math.floor(minutes / 1440)}j`
}

const activityIconMap = {
  inscription: { icon: UserPlus, styles: 'bg-mint-100 dark:bg-mint-500/10 text-mint-600 dark:text-mint-400' },
  validation: { icon: UserCheck, styles: 'bg-primary-100 dark:bg-primary-500/10 text-primary-600 dark:text-primary-400' },
  signalement: { icon: AlertCircle, styles: 'bg-urgence-100 dark:bg-urgence-500/10 text-urgence-600 dark:text-urgence-400' },
  centre: { icon: Hospital, styles: 'bg-amber-100 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400' },
}

export default function AdminDashboard() {
  const [stats, setStats] = useState(null)
  const [pendingDoctors, setPendingDoctors] = useState([])
  const [loading, setLoading] = useState(true)
  const [greeting, setGreeting] = useState('')
  const [currentDate, setCurrentDate] = useState('')
  const toast = useToast()

  useEffect(() => {
    const hour = new Date().getHours()
    if (hour < 12) setGreeting('Bonjour')
    else if (hour < 18) setGreeting('Bon après-midi')
    else setGreeting('Bonsoir')
    setCurrentDate(
      new Date().toLocaleDateString('fr-FR', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    )
  }, [])

  useEffect(() => {
    Promise.all([
      api.get('/api/admin/stats'),
      api.get('/api/admin/medecins/en-attente'),
    ])
      .then(([statsRes, doctorsRes]) => {
        setStats(statsRes.data)
        setPendingDoctors(doctorsRes.data.medecins?.slice(0, 5) || [])
      })
      .catch(() => toast.error('Erreur lors du chargement du dashboard'))
      .finally(() => setLoading(false))
  }, [])

  const handleValidation = useCallback(async (doctorId, estValide) => {
    try {
      await api.patch(`/api/admin/medecins/${doctorId}/validation`, { estValide })
      toast.success(estValide ? 'Médecin validé avec succès' : 'Validation refusée')
      setPendingDoctors((prev) => prev.filter((d) => d.id !== doctorId))
      const { data } = await api.get('/api/admin/stats')
      setStats(data)
    } catch {
      toast.error('Erreur lors de la validation')
    }
  }, [])

  const chartData = [
    { month: 'Jan', utilisateurs: 120, consultations: 45 },
    { month: 'Fév', utilisateurs: 180, consultations: 72 },
    { month: 'Mar', utilisateurs: 240, consultations: 98 },
    { month: 'Avr', utilisateurs: 320, consultations: 135 },
    { month: 'Mai', utilisateurs: 410, consultations: 178 },
    { month: 'Juin', utilisateurs: 520, consultations: 234 },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <LoadingSpinner label="Chargement du dashboard..." />
      </div>
    )
  }

  const kpis = [
    {
      id: 'kpi-total-users',
      label: 'Utilisateurs Total',
      value: stats?.utilisateurs?.total || 0,
      icon: Users,
      accent: 'primary',
      href: '/admin/utilisateurs',
    },
    {
      id: 'kpi-active-doctors',
      label: 'Médecins Actifs',
      value: stats?.utilisateurs?.medecinsValides || 0,
      icon: Stethoscope,
      accent: 'mint',
      href: '/admin/utilisateurs',
    },
    {
      id: 'kpi-pending-validations',
      label: 'En Attente',
      value: stats?.utilisateurs?.medecinsEnAttente || 0,
      icon: AlertCircle,
      accent: 'urgence',
      badge: stats?.utilisateurs?.medecinsEnAttente > 0,
      href: '/admin/medecins',
    },
    {
      id: 'kpi-active-centers',
      label: 'Centres Actifs',
      value: stats?.contenu?.centres || 0,
      icon: Hospital,
      accent: 'primary',
      href: '/admin/centres',
    },
  ]

  const secondaryKpis = [
    {
      id: 'kpi-diseases',
      label: 'Maladies',
      value: stats?.contenu?.maladies || 0,
      icon: BookOpen,
      href: '/admin/catalogue',
    },
    {
      id: 'kpi-consultations',
      label: 'Consultations',
      value: stats?.activite?.consultations || 0,
      icon: Activity,
      href: '/admin',
    },
    {
      id: 'kpi-messages',
      label: 'Messages',
      value: stats?.activite?.messages || 0,
      icon: MessageSquare,
      href: '/admin',
    },
    {
      id: 'kpi-reported-reviews',
      label: 'Avis Signalés',
      value: stats?.activite?.avisSignales || 0,
      icon: Star,
      href: '/admin/avis',
    },
  ]

  const quickLinks = [
    {
      title: 'Valider les médecins',
      description: `${stats?.utilisateurs?.medecinsEnAttente || 0} en attente`,
      href: '/admin/medecins',
      icon: Stethoscope,
      accent: 'mint',
    },
    {
      title: 'Gérer les centres',
      description: 'Ajouter ou modifier',
      href: '/admin/centres',
      icon: Hospital,
      accent: 'primary',
    },
    {
      title: 'Modérer les avis',
      description: `${stats?.activite?.avisSignales || 0} signalés`,
      href: '/admin/avis',
      icon: Star,
      accent: 'urgence',
    },
  ]

  return (
    <div id="admin-dashboard" className="max-w-7xl mx-auto space-y-6 relative">
      {/* Decorative gradient blobs */}
      <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full bg-mint-500/[0.03] blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -left-20 w-72 h-72 rounded-full bg-primary-500/[0.03] blur-3xl pointer-events-none" />

      {/* Greeting header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3"
      >
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h1 className="font-display font-bold text-2xl text-primary-900 dark:text-sable">
              {greeting},{' '}
              <span className="bg-gradient-to-r from-mint-600 to-mint-500 bg-clip-text text-transparent">
                Administrateur
              </span>
            </h1>
          </div>
          <p className="text-sm text-primary-300/80 capitalize flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-primary-200" strokeWidth={1.5} />
            {currentDate}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/70 dark:bg-primary-800/70 backdrop-blur-sm border border-primary-100 dark:border-white/5 shadow-sm">
            <div className="relative">
              <ShieldCheck className="w-4 h-4 text-mint-500" />
              <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-mint-500 animate-ping" />
            </div>
            <span className="text-xs font-medium text-primary-500 dark:text-sable">
              Plateforme opérationnelle
            </span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/70 dark:bg-primary-800/70 backdrop-blur-sm border border-primary-100 dark:border-white/5">
            <RefreshCw className="w-3 h-3 text-primary-300" strokeWidth={1.5} />
            <span className="text-[11px] text-primary-300/70">Mis à jour récemment</span>
          </div>
        </div>
      </motion.div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon
          const trend = kpiTrends[kpi.id]
          return (
            <motion.div
              key={kpi.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.06 }}
            >
              <Link
                id={kpi.id}
                href={kpi.href}
                className="group relative block overflow-hidden rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5"
              >
                {/* Accent bar */}
                <div className={`absolute top-0 left-0 right-0 h-1 ${kpiAccentBar[kpi.accent]} opacity-60`} />

                {/* Gradient overlay on hover */}
                <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-br ${kpiIconGradient[kpi.accent]}`} />

                {kpi.badge && (
                  <div className="absolute top-4 right-4 z-10">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-urgence-500 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-urgence-500" />
                    </span>
                  </div>
                )}

                <div className="relative p-5 z-10">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${kpiIconGradient[kpi.accent]} flex items-center justify-center group-hover:scale-110 group-hover:rotate-[2deg] transition-all duration-300`}>
                      <Icon className={`w-5.5 h-5.5 ${kpiIconColor[kpi.accent]}`} strokeWidth={1.6} />
                    </div>
                    {trend && (
                      <span className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] font-bold ${
                        trend.up
                          ? 'bg-mint-100 text-mint-700 dark:bg-mint-500/10 dark:text-mint-400'
                          : 'bg-urgence-100 text-urgence-700 dark:bg-urgence-500/10 dark:text-urgence-400'
                      }`}>
                        {trend.up
                          ? <TrendingUp className="w-2.5 h-2.5" strokeWidth={3} />
                          : <TrendingDown className="w-2.5 h-2.5" strokeWidth={3} />
                        }
                        {trend.value}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] font-semibold text-primary-300/80 uppercase tracking-wider mb-0.5">{kpi.label}</p>
                  <p className="font-display font-bold text-3xl text-primary-900 dark:text-sable tabular-nums">
                    <AnimatedNumber value={kpi.value} />
                  </p>
                </div>
              </Link>
            </motion.div>
          )
        })}
      </div>

      {/* Secondary KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {secondaryKpis.map((kpi, index) => {
          const Icon = kpi.icon
          return (
            <motion.div
              key={kpi.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.04 }}
            >
              <Link
                id={kpi.id}
                href={kpi.href}
                className="flex items-center gap-3 p-4 rounded-xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 hover:border-mint-500/40 hover:shadow-md transition-all duration-200 group"
              >
                <div className="w-10 h-10 rounded-lg bg-primary-50 dark:bg-primary-900/40 flex items-center justify-center group-hover:scale-105 transition-transform relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-mint-500/0 to-mint-500/0 group-hover:from-mint-500/10 group-hover:to-mint-500/5 transition-all duration-300" />
                  <Icon className="w-4.5 h-4.5 text-primary-300 group-hover:text-mint-500 transition-colors relative z-10" strokeWidth={1.6} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-semibold text-primary-300/70 uppercase tracking-wider truncate">{kpi.label}</p>
                  <p className="font-display font-bold text-lg text-primary-900 dark:text-sable tabular-nums">
                    <AnimatedNumber value={kpi.value} />
                  </p>
                </div>
              </Link>
            </motion.div>
          )
        })}
      </div>

      {/* Chart + Quick Links + Activity */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="lg:col-span-2 p-6 rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm relative overflow-hidden"
        >
          <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-mint-500/[0.03] blur-2xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-mint-500/20 to-mint-500/5 flex items-center justify-center">
                  <TrendingUp className="w-4.5 h-4.5 text-mint-500" strokeWidth={1.8} />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-base text-primary-900 dark:text-sable">
                    Évolution de la plateforme
                  </h3>
                  <p className="text-xs text-primary-300/70">Croissance sur 6 mois</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-mint-500" />
                  <span className="text-[11px] text-primary-300 font-medium">Utilisateurs</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-primary-500" />
                  <span className="text-[11px] text-primary-300 font-medium">Consultations</span>
                </div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={290}>
              <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorU" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorC" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1E3A5F" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#1E3A5F" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="4 4" stroke="#CBDBEA" opacity={0.25} vertical={false} />
                <XAxis dataKey="month" stroke="#6F94B8" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} dy={8} />
                <YAxis stroke="#6F94B8" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} dx={-4} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1E3A5F',
                    border: 'none',
                    borderRadius: '12px',
                    color: '#F6F3EC',
                    fontSize: '12px',
                    boxShadow: '0 8px 32px rgba(30, 58, 95, 0.3)',
                    padding: '12px 16px',
                  }}
                  labelStyle={{ color: '#6F94B8', fontSize: '11px', marginBottom: '4px' }}
                />
                <Area
                  type="monotone"
                  dataKey="utilisateurs"
                  stroke="#10B981"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorU)"
                  dot={false}
                  activeDot={{ r: 5, fill: '#10B981', stroke: '#fff', strokeWidth: 2 }}
                />
                <Area
                  type="monotone"
                  dataKey="consultations"
                  stroke="#1E3A5F"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorC)"
                  dot={false}
                  activeDot={{ r: 5, fill: '#1E3A5F', stroke: '#fff', strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-primary-300" strokeWidth={1.6} />
              <h3 className="font-display font-semibold text-base text-primary-900 dark:text-sable">
                Actions rapides
              </h3>
            </div>
            <div className="space-y-3">
              {quickLinks.map((link) => {
                const Icon = link.icon
                return (
                  <Link
                    key={link.href}
                    id={`quicklink-${link.href.replace(/\//g, '-')}`}
                    href={link.href}
                    className="group flex items-center gap-4 p-4 rounded-xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 hover:border-mint-500/40 hover:shadow-md transition-all duration-200"
                  >
                    <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${kpiIconGradient[link.accent]} flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                      <Icon className={`w-5 h-5 ${kpiIconColor[link.accent]}`} strokeWidth={1.6} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-primary-900 dark:text-sable group-hover:text-mint-500 transition-colors">
                        {link.title}
                      </p>
                      <p className="text-xs text-primary-300/70">{link.description}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-primary-200 group-hover:text-mint-500 group-hover:translate-x-0.5 transition-all" strokeWidth={1.6} />
                  </Link>
                )
              })}
            </div>
          </motion.div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
            className="rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm overflow-hidden"
          >
            <div className="px-5 py-4 border-b border-primary-100/50 dark:border-white/5">
              <h3 className="font-display font-semibold text-sm text-primary-900 dark:text-sable">
                Activité récente
              </h3>
            </div>
            <div className="divide-y divide-primary-100/30 dark:divide-white/5">
              {recentActivity.map((item) => {
                const activity = activityIconMap[item.type]
                const ActivityIcon = activity.icon
                return (
                  <div key={item.id} className="flex items-start gap-3 px-5 py-3.5 hover:bg-primary-50/40 dark:hover:bg-white/[0.02] transition-colors">
                    <div className={`w-7 h-7 rounded-lg shrink-0 flex items-center justify-center ${activity.styles}`}>
                      <ActivityIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-primary-900 dark:text-sable truncate">{item.user}</p>
                      <p className="text-[11px] text-primary-400/70 truncate">{item.detail}</p>
                    </div>
                    <span className="text-[10px] text-primary-300/50 shrink-0 pt-0.5 font-medium">
                      <TimeAgo minutes={item.timeOffset} />
                    </span>
                  </div>
                )
              })}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Pending Doctors */}
      {pendingDoctors.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="rounded-2xl bg-white dark:bg-primary-800 border border-primary-100/60 dark:border-white/5 shadow-sm overflow-hidden"
        >
          <div className="px-6 py-5 border-b border-primary-100/50 dark:border-white/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-100 dark:bg-amber-500/10 flex items-center justify-center">
                  <Clock className="w-4.5 h-4.5 text-amber-600 dark:text-amber-400" strokeWidth={1.8} />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-base text-primary-900 dark:text-sable">
                    Médecins en attente de validation
                  </h3>
                  <p className="text-xs text-primary-300/70 mt-0.5">
                    {pendingDoctors.length} médecin{pendingDoctors.length > 1 ? 's' : ''} à vérifier
                  </p>
                </div>
              </div>
              <Link
                id="view-all-pending-doctors"
                href="/admin/medecins"
                className="inline-flex items-center gap-1 text-sm font-medium text-mint-500 hover:text-mint-700 transition-colors"
              >
                Voir tout
                <ArrowRight className="w-3.5 h-3.5" strokeWidth={2} />
              </Link>
            </div>
          </div>
          <div className="divide-y divide-primary-100/50 dark:divide-white/5">
            {pendingDoctors.map((doctor) => {
              const initials = ((doctor.prenom?.[0] || '') + (doctor.nom?.[0] || '')).toUpperCase()
              return (
                <div
                  key={doctor.id}
                  id={`pending-doctor-${doctor.id}`}
                  className="flex items-center gap-4 px-6 py-4 hover:bg-primary-50/50 dark:hover:bg-white/[0.02] transition-colors"
                >
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-mint-500 to-mint-600 flex items-center justify-center text-white font-bold text-sm shadow-sm shrink-0">
                    {initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-sm text-primary-900 dark:text-sable truncate">
                        Dr. {doctor.prenom} {doctor.nom}
                      </p>
                      <span className="shrink-0 inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400">
                        En attente
                      </span>
                    </div>
                    <p className="text-xs text-primary-300/70 truncate">
                      {doctor.specialite} — N° {doctor.numeroOrdre}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      id={`approve-doctor-${doctor.id}`}
                      onClick={() => handleValidation(doctor.id, true)}
                      className="p-2 rounded-lg bg-mint-500/10 hover:bg-mint-500/20 text-mint-500 hover:text-mint-700 transition-all"
                      title="Approuver"
                    >
                      <CheckCircle className="w-4.5 h-4.5" strokeWidth={1.8} />
                    </button>
                    <button
                      id={`reject-doctor-${doctor.id}`}
                      onClick={() => handleValidation(doctor.id, false)}
                      className="p-2 rounded-lg bg-urgence-500/10 hover:bg-urgence-500/20 text-urgence-500 hover:text-urgence-700 transition-all"
                      title="Rejeter"
                    >
                      <XCircle className="w-4.5 h-4.5" strokeWidth={1.8} />
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </motion.div>
      )}
    </div>
  )
}
