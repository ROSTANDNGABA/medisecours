'use client'

import dynamic from 'next/dynamic'
import { useEffect, useState, useMemo } from 'react'
import { LocateFixed, Phone, Clock, MapPin, Search, Filter } from 'lucide-react'
import api from '../../api/axios'
import { useGeolocation } from '../../hooks/useGeolocation'
import { useDebounce } from '../../hooks/useDebounce'
import LoadingSpinner from '../../components/ui/LoadingSpinner'
import EmptyState from '../../components/ui/EmptyState'
import { useToast } from '../../components/ui/Toast'

const CentresMap = dynamic(() => import('../../components/CentresMap'), {
  ssr: false,
  loading: () => (
    <div className="h-full w-full flex items-center justify-center">
      <LoadingSpinner label="Chargement de la carte…" />
    </div>
  ),
})

const TYPES = [
  { value: '', label: 'Tous types' },
  { value: 'chu', label: 'CHU' },
  { value: 'hopital_general', label: 'Hôpital général' },
  { value: 'hopital_de_district', label: 'Hôpital de district' },
  { value: 'clinique_privee', label: 'Clinique privée' },
  { value: 'pharmacie', label: 'Pharmacie' },
  { value: 'cma', label: 'CMA' },
  { value: 'csi', label: 'CSI' },
  { value: 'laboratoire', label: 'Laboratoire' },
]

/**
 * Calcule la distance Haversine en km entre deux coordonnées.
 * Utilisé pour le tri côté client (les distances serveur ne sont disponibles
 * qu'après géolocalisation).
 */
function distanceKm(a, b) {
  if (!a || !b) return null
  const R    = 6371
  const dLat = ((b.lat - a.lat) * Math.PI) / 180
  const dLng = ((b.lng - a.lng) * Math.PI) / 180
  const lat1 = (a.lat * Math.PI) / 180
  const lat2 = (b.lat * Math.PI) / 180
  const h    = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h))
}

export default function CentresPage() {
  const [centres,        setCentres]        = useState([])
  const [loading,        setLoading]        = useState(false)
  const [loadingProches, setLoadingProches] = useState(false)
  const [selected,       setSelected]       = useState(null)
  const [typeFilter,     setTypeFilter]     = useState('')
  const [searchVille,    setSearchVille]    = useState('')
  const [urgencesOnly,   setUrgencesOnly]   = useState(false)
  const [modeProches,    setModeProches]    = useState(false) // true = résultats géolocalisés

  const { position, error: geoError, loading: locating, locate } = useGeolocation()
  const toast        = useToast()
  const debouncedVille = useDebounce(searchVille, 500)

  // ── Chargement UNIQUEMENT sur action explicite de l'utilisateur ────────────
  // On NE charge PAS tous les centres au démarrage.
  // L'utilisateur doit soit se géolocaliser, soit chercher par ville.
  // Évite de charger 500 centres inutilement à chaque visite.

  const fetchProches = (pos) => {
    setLoadingProches(true)
    setModeProches(true)
    api.get('/api/centres_de_santes/proches', {
      params: {
        lat:    pos.lat,
        lng:    pos.lng,
        rayon:  25,
        limit:  20,
        ...(typeFilter ? { type: typeFilter } : {}),
      },
    })
      .then((res) => {
        const data = res.data['hydra:member'] || res.data.member || res.data
        setCentres(Array.isArray(data) ? data : [])
      })
      .catch(() => toast.error('Impossible de récupérer les centres proches.'))
      .finally(() => setLoadingProches(false))
  }

  const fetchParVille = (ville) => {
    setLoading(true)
    setModeProches(false)
    api.get('/api/centre_de_santes', {
      params: {
        ville,
        itemsPerPage: 30,
        ...(typeFilter ? { type: typeFilter } : {}),
        ...(urgencesOnly ? { urgences24h: true } : {}),
      },
    })
      .then((res) => {
        const data = res.data['hydra:member'] || res.data.member || res.data
        setCentres(Array.isArray(data) ? data : [])
      })
      .catch(() => toast.error('Impossible de charger les centres.'))
      .finally(() => setLoading(false))
  }

  // Déclencher la recherche par ville quand le debouncedVille change
  useEffect(() => {
    if (debouncedVille.trim().length >= 2) {
      fetchParVille(debouncedVille.trim())
    }
  }, [debouncedVille, typeFilter, urgencesOnly]) // eslint-disable-line react-hooks/exhaustive-deps

  // Quand la position GPS est obtenue, charger les centres proches
  useEffect(() => {
    if (position) {
      fetchProches(position)
    }
  }, [position]) // eslint-disable-line react-hooks/exhaustive-deps

  // Re-filtrer si le filtre de type change et qu'on est en mode géolocalisation
  useEffect(() => {
    if (modeProches && position) {
      fetchProches(position)
    }
  }, [typeFilter]) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Tri des résultats ─────────────────────────────────────────────────────
  const sorted = useMemo(() => {
    let list = [...centres]

    // Filtre urgences 24h côté client si mode géolocalisé
    if (urgencesOnly) {
      list = list.filter((c) => c.urgences24h)
    }

    // Tri par distance si position disponible
    if (position) {
      list.sort((a, b) => {
        // Utiliser la distance renvoyée par le serveur si disponible, sinon calculer
        const dA = a.distance ?? distanceKm(position, { lat: a.latitude, lng: a.longitude })
        const dB = b.distance ?? distanceKm(position, { lat: b.latitude, lng: b.longitude })
        return (dA ?? 0) - (dB ?? 0)
      })
    }

    return list
  }, [centres, position, urgencesOnly])

  const isEmpty    = !loading && !loadingProches && sorted.length === 0
  const hasResults = sorted.length > 0
  const isLoading  = loading || loadingProches

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">

      {/* ── En-tête ── */}
      <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display font-bold text-3xl text-primary-900 dark:text-sable">
            Centres de santé
          </h1>
          <p className="text-primary-300 text-sm mt-1">
            Localisez-vous ou cherchez par ville pour trouver les centres proches.
          </p>
        </div>
        <button
          onClick={locate}
          disabled={locating}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-mint-500 hover:bg-mint-700 text-white font-semibold shadow-lg transition disabled:opacity-60"
        >
          <LocateFixed className="w-4 h-4" />
          {locating ? 'Localisation…' : 'Me localiser'}
        </button>
      </div>

      {/* ── Erreur GPS ── */}
      {geoError && (
        <div className="mb-4 px-4 py-3 rounded-xl bg-urgence-50 dark:bg-urgence-900/20 text-urgence-700 text-sm">
          {geoError}
        </div>
      )}

      {/* ── Filtres ── */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        {/* Recherche par ville */}
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary-300" />
          <input
            value={searchVille}
            onChange={(e) => setSearchVille(e.target.value)}
            placeholder="Chercher par ville (ex : Yaoundé)"
            className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-primary-100 dark:border-white/10 bg-white/80 dark:bg-primary-900/40 text-sm focus:outline-none focus:ring-2 focus:ring-mint-500"
          />
        </div>

        {/* Filtre type */}
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary-300 pointer-events-none" />
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="pl-9 pr-4 py-2.5 rounded-xl border border-primary-100 dark:border-white/10 bg-white/80 dark:bg-primary-900/40 text-sm focus:outline-none focus:ring-2 focus:ring-mint-500 text-primary-700 dark:text-sable"
          >
            {TYPES.map((t) => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>

        {/* Urgences 24h */}
        <label className="flex items-center gap-2 cursor-pointer px-3 py-2.5 rounded-xl border border-primary-100 dark:border-white/10 bg-white/80 dark:bg-primary-900/40">
          <input
            type="checkbox"
            checked={urgencesOnly}
            onChange={(e) => setUrgencesOnly(e.target.checked)}
            className="w-4 h-4 accent-mint-500"
          />
          <span className="text-sm text-primary-700 dark:text-sable">Urgences 24h/7j</span>
        </label>
      </div>

      {/* ── Contenu principal ── */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

        {/* Carte */}
        <div className="lg:col-span-3 rounded-2xl overflow-hidden shadow-xl border border-white/50 dark:border-white/10 h-[420px] lg:h-[600px]">
          <CentresMap centres={sorted} position={position} onSelect={setSelected} />
        </div>

        {/* Liste */}
        <div className="lg:col-span-2 max-h-[600px] overflow-y-auto pr-1">
          {isLoading ? (
            <LoadingSpinner label="Chargement des centres…" />
          ) : !hasResults ? (
            <EmptyState
              title={
                !position && !debouncedVille
                  ? 'Aucune recherche effectuée'
                  : 'Aucun centre trouvé'
              }
              description={
                !position && !debouncedVille
                  ? 'Cliquez sur "Me localiser" ou tapez une ville pour trouver des centres proches.'
                  : 'Essayez un rayon plus grand ou un autre type d\'établissement.'
              }
            />
          ) : (
            <div className="space-y-3">
              {modeProches && position && (
                <p className="text-xs text-primary-400 px-1">
                  {sorted.length} centre{sorted.length > 1 ? 's' : ''} dans un rayon de 25 km
                </p>
              )}
              {sorted.map((c) => {
                const dist = c.distance ?? (position
                  ? distanceKm(position, { lat: c.latitude, lng: c.longitude })
                  : null)
                return (
                  <CentreCard
                    key={c.id}
                    centre={c}
                    dist={dist}
                    selected={selected === c.id}
                    onSelect={() => setSelected(c.id)}
                  />
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Carte centre individuel ──────────────────────────────────────────────────

function CentreCard({ centre: c, dist, selected, onSelect }) {
  return (
    <div
      onClick={onSelect}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && onSelect()}
      className={`rounded-2xl p-4 border cursor-pointer transition ${
        selected
          ? 'border-mint-500 bg-mint-100/30 dark:bg-mint-900/20'
          : 'border-primary-100 dark:border-white/10 bg-white/70 dark:bg-primary-700/40 hover:border-primary-300'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm text-primary-900 dark:text-sable truncate">{c.nom}</h3>
          {c.urgences24h && (
            <span className="inline-block text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-full bg-urgence-100 text-urgence-700 mt-0.5">
              Urgences 24h
            </span>
          )}
        </div>
        {dist !== null && (
          <span className="text-xs font-bold text-mint-700 bg-mint-100 px-2 py-0.5 rounded-full shrink-0">
            {dist.toFixed(1)} km
          </span>
        )}
      </div>

      <p className="text-xs text-primary-300 flex items-center gap-1 mt-1.5">
        <MapPin className="w-3 h-3 shrink-0" />
        {c.adresse}{c.ville ? `, ${c.ville}` : ''}
      </p>

      {c.telephone && (
        <a
          href={`tel:${c.telephone}`}
          onClick={(e) => e.stopPropagation()}
          className="text-xs text-mint-600 dark:text-mint-400 flex items-center gap-1 mt-1 hover:underline"
        >
          <Phone className="w-3 h-3 shrink-0" />
          {c.telephone}
        </a>
      )}

      {c.horaires && (
        <p className="text-xs text-primary-300 flex items-center gap-1 mt-1">
          <Clock className="w-3 h-3 shrink-0" />
          {c.horaires}
        </p>
      )}
    </div>
  )
}
