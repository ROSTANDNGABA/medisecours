import axios from 'axios'

/**
 * Instance Axios configurée pour l'API MediSecours+.
 *
 * La baseURL est lue depuis la variable d'environnement Next.js NEXT_PUBLIC_API_BASE_URL.
 * Configurer .env.local :
 *   NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:8000   (développement)
 *   NEXT_PUBLIC_API_BASE_URL=https://api.medisecours.cm  (production)
 */
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_BASE_URL || 'http://127.0.0.1:8000',
  headers: {
    Accept: 'application/ld+json',
  },
  // Timeout de 15 secondes — raisonnable pour le réseau camerounais (3G/4G)
  timeout: 15000,
})

// ── Intercepteur requête : injecter le token JWT ─────────────────────────────
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('medisecours_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
  }
  return config
})

// ── Intercepteur réponse : gérer les erreurs globalement ────────────────────
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status

    // 401 — Token expiré ou invalide : déconnexion propre
    if (status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('medisecours_token')
      localStorage.removeItem('medisecours_user')
      document.cookie = 'medisecours_token=; path=/; max-age=0; SameSite=Strict'
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    }

    // 429 — Rate limit atteint : message utilisateur lisible
    if (status === 429) {
      error.userMessage = 'Trop de requêtes. Veuillez patienter quelques instants.'
    }

    // 410 — Endpoint désactivé (ex: legacy /api/login)
    if (status === 410) {
      error.userMessage = 'Cet endpoint est désactivé. Merci de mettre à jour votre application.'
    }

    return Promise.reject(error)
  }
)

export default api
