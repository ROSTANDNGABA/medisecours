'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { HeartPulse, Menu, X, Sun, Moon, MessageCircle, UserCircle, LogOut } from 'lucide-react'
import { useAuth } from '../../hooks/useAuth'

const links = [
  { to: '/', label: 'Accueil' },
  { to: '/categories', label: 'Catégories' },
  { to: '/maladies', label: 'Maladies' },
  { to: '/centres', label: 'Centres de santé' },
  { to: '/medecins', label: 'Médecins' },
]

export default function Navbar() {
  const [open,       setOpen]       = useState(false)
  const [dark,       setDark]       = useState(false)
  const [darkReady,  setDarkReady]  = useState(false)

  // `mounted` vient du contexte auth — true uniquement après hydration + lecture localStorage
  const { isAuthenticated, user, isAdmin, logout, mounted } = useAuth()

  const pathname = usePathname()
  const router   = useRouter()

  // Thème sombre — également chargé après hydration pour éviter le mismatch
  useEffect(() => {
    const saved = localStorage.getItem('medisecours_theme')
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
    const isDark = saved ? saved === 'dark' : prefersDark
    setDark(isDark)
    setDarkReady(true)
  }, [])

  useEffect(() => {
    if (!darkReady) return
    document.documentElement.classList.toggle('dark', dark)
    localStorage.setItem('medisecours_theme', dark ? 'dark' : 'light')
  }, [dark, darkReady])

  const initials = user
    ? `${user.prenom?.[0] ?? ''}${user.nom?.[0] ?? ''}`.toUpperCase()
    : ''

  const isActive = (to) => (to === '/' ? pathname === '/' : pathname.startsWith(to))

  return (
    <header className="sticky top-0 z-50 bg-white/70 dark:bg-primary-900/70 backdrop-blur-lg border-b border-white/40 dark:border-white/5">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">

        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-2 font-display font-extrabold text-lg text-primary-500 dark:text-mint-500"
        >
          <HeartPulse className="w-6 h-6 text-urgence-500" />
          MediSecours<span className="text-mint-500">+</span>
        </Link>

        {/* Navigation desktop */}
        <nav className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.to}
              href={l.to}
              className={`px-3 py-2 rounded-xl text-sm font-medium transition ${
                isActive(l.to)
                  ? 'bg-primary-500 text-white'
                  : 'text-primary-700 dark:text-sable hover:bg-primary-100 dark:hover:bg-primary-700'
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        {/* Actions desktop */}
        <div className="flex items-center gap-2">

          {/* Toggle thème — même rendu serveur/client grâce à darkReady */}
          <button
            onClick={() => setDark((d) => !d)}
            className="p-2 rounded-xl hover:bg-primary-100 dark:hover:bg-primary-700 text-primary-500 dark:text-sable"
            aria-label="Basculer le mode sombre"
          >
            {darkReady && dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          {/*
            Section auth — rendue UNIQUEMENT après hydration (mounted=true).
            Avant mounted, on affiche un squelette neutre identique côté serveur et client
            → plus aucun mismatch d'hydration.
          */}
          {!mounted ? (
            /* Squelette neutre : même rendu serveur et client */
            <div className="hidden sm:block w-24 h-9 rounded-xl bg-primary-100 dark:bg-primary-800 animate-pulse" />
          ) : isAuthenticated ? (
            <div className="hidden sm:flex items-center gap-1">
              <Link
                href="/messages"
                className="p-2 rounded-xl hover:bg-primary-100 dark:hover:bg-primary-700 text-primary-500 dark:text-sable"
                aria-label="Messages"
              >
                <MessageCircle className="w-5 h-5" />
              </Link>
              {isAdmin && (
                <Link
                  href="/admin"
                  className="px-3 py-2 rounded-xl text-sm font-medium text-primary-700 dark:text-sable hover:bg-primary-100 dark:hover:bg-primary-700"
                >
                  Admin
                </Link>
              )}
              <Link
                href="/profil"
                className="w-9 h-9 rounded-full bg-primary-500 text-white flex items-center justify-center text-xs font-bold"
                title={`${user?.prenom ?? ''} ${user?.nom ?? ''}`}
              >
                {initials || <UserCircle className="w-5 h-5" />}
              </Link>
              <button
                onClick={() => { logout(); router.push('/') }}
                className="p-2 rounded-xl hover:bg-urgence-100 text-primary-500 hover:text-urgence-700 dark:text-sable"
                aria-label="Se déconnecter"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="hidden sm:inline-flex px-4 py-2 rounded-xl bg-mint-500 hover:bg-mint-700 text-white text-sm font-semibold shadow-lg transition"
            >
              Connexion
            </Link>
          )}

          {/* Bouton menu mobile */}
          <button
            className="md:hidden p-2 text-primary-500 dark:text-sable"
            onClick={() => setOpen((o) => !o)}
            aria-label="Menu"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Menu mobile */}
      {open && (
        <nav className="md:hidden border-t border-white/40 dark:border-white/5 px-4 py-3 flex flex-col gap-1 bg-white/90 dark:bg-primary-900/90">
          {links.map((l) => (
            <Link
              key={l.to}
              href={l.to}
              onClick={() => setOpen(false)}
              className={`px-3 py-2.5 rounded-xl text-sm font-medium ${
                isActive(l.to) ? 'bg-primary-500 text-white' : 'text-primary-700 dark:text-sable'
              }`}
            >
              {l.label}
            </Link>
          ))}

          {/* Même logique : attendre mounted pour éviter le mismatch */}
          {mounted && isAuthenticated ? (
            <>
              <Link
                onClick={() => setOpen(false)}
                href="/messages"
                className="px-3 py-2.5 rounded-xl text-sm font-medium text-primary-700 dark:text-sable"
              >
                Messagerie
              </Link>
              <Link
                onClick={() => setOpen(false)}
                href="/profil"
                className="px-3 py-2.5 rounded-xl text-sm font-medium text-primary-700 dark:text-sable"
              >
                Profil
              </Link>
              {isAdmin && (
                <Link
                  onClick={() => setOpen(false)}
                  href="/admin"
                  className="px-3 py-2.5 rounded-xl text-sm font-medium text-primary-700 dark:text-sable"
                >
                  Admin
                </Link>
              )}
              <button
                onClick={() => { logout(); setOpen(false); router.push('/') }}
                className="text-left px-3 py-2.5 rounded-xl text-sm font-medium text-urgence-700"
              >
                Déconnexion
              </button>
            </>
          ) : (
            <Link
              onClick={() => setOpen(false)}
              href="/login"
              className="px-3 py-2.5 rounded-xl text-sm font-semibold bg-mint-500 text-white text-center"
            >
              Connexion
            </Link>
          )}
        </nav>
      )}
    </header>
  )
}
