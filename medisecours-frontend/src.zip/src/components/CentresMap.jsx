'use client'

import { useEffect } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import L from 'leaflet'

delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  // Icônes bundlées localement — évite la dépendance au CDN unpkg
  // indispensable pour les réseaux 3G/4G camerounais parfois instables
  iconRetinaUrl: '/leaflet-marker-icon-2x.png',
  iconUrl:       '/leaflet-marker-icon.png',
  shadowUrl:     '/leaflet-marker-shadow.png',
})

const CAMEROUN_CENTER = [5.369, 12.354] // Centre géographique du Cameroun

function Recenter({ center }) {
  const map = useMap()
  useEffect(() => {
    if (center) map.flyTo(center, 13, { duration: 1 })
  }, [center])
  return null
}

export default function CentresMap({ centres, position, onSelect }) {
  return (
    <MapContainer center={CAMEROUN_CENTER} zoom={6} style={{ height: '100%', width: '100%' }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution="&copy; OpenStreetMap contributors"
      />
      {position && <Recenter center={[position.lat, position.lng]} />}
      {centres.map((c) => (
        <Marker
          key={c.id}
          position={[c.latitude, c.longitude]}
          eventHandlers={{ click: () => onSelect?.(c.id) }}
        >
          <Popup>
            <div className="text-sm">
              <p className="font-semibold">{c.nom}</p>
              <p>{c.adresse}</p>
              {c.telephone && <p>{c.telephone}</p>}
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  )
}
