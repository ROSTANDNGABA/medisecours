'use client'

import { useEffect, useState } from 'react'
import { Plus, Pencil, Trash2, X, Save } from 'lucide-react'
import api from '../../api/axios'
import LoadingSpinner from '../ui/LoadingSpinner'
import EmptyState from '../ui/EmptyState'
import { useToast } from '../ui/Toast'

// Generic admin CRUD table driven by a field schema.
// fields: [{ key, label, type: 'text'|'textarea'|'color'|'select'|'checkbox', options? }]
export default function CrudTable({ endpoint, fields, title }) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(null)
  const [saving, setSaving] = useState(false)
  const toast = useToast()

  const load = () => {
    setLoading(true)
    api.get(endpoint)
      .then((res) => {
        const data = res.data['hydra:member'] || res.data.member || res.data
        setItems(Array.isArray(data) ? data : [])
      })
      .catch(() => toast.error(`Impossible de charger : ${title}`))
      .finally(() => setLoading(false))
  }

  useEffect(load, [endpoint])

  const startCreate = () => setEditing(Object.fromEntries(fields.map((f) => [f.key, f.type === 'checkbox' ? false : ''])))
  const startEdit = (item) => setEditing({ ...item })

  const handleDelete = async (id) => {
    if (!confirm('Supprimer cet élément ?')) return
    try {
      await api.delete(`${endpoint}/${id}`)
      setItems((it) => it.filter((i) => i.id !== id))
      toast.success('Élément supprimé.')
    } catch {
      toast.error('Échec de la suppression.')
    }
  }

  const handleSave = async () => {
    setSaving(true)
    const payload = Object.fromEntries(fields.map((f) => [f.key, editing[f.key]]))
    try {
      if (editing.id) {
        const { data } = await api.patch(`${endpoint}/${editing.id}`, payload, { headers: { 'Content-Type': 'application/merge-patch+json' } })
        setItems((it) => it.map((i) => (i.id === editing.id ? { ...i, ...data } : i)))
        toast.success('Élément mis à jour.')
      } else {
        const { data } = await api.post(endpoint, payload)
        setItems((it) => [...it, data])
        toast.success('Élément créé.')
      }
      setEditing(null)
    } catch {
      toast.error("Échec de l'enregistrement.")
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-primary-900 dark:text-sable">{title}</h3>
        <button onClick={startCreate} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-mint-500 hover:bg-mint-700 text-white text-sm font-semibold">
          <Plus className="w-4 h-4" /> Ajouter
        </button>
      </div>

      {loading ? (
        <LoadingSpinner size="sm" />
      ) : items.length === 0 ? (
        <EmptyState title="Aucun élément" description={`Ajoutez le premier élément pour : ${title}`} />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-primary-100 dark:border-white/10">
          <table className="w-full text-sm">
            <thead className="bg-primary-100/60 dark:bg-primary-900/40 text-primary-700 dark:text-sable">
              <tr>
                {fields.slice(0, 3).map((f) => <th key={f.key} className="text-left px-4 py-2.5 font-semibold">{f.label}</th>)}
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id} className="border-t border-primary-100 dark:border-white/10">
                  {fields.slice(0, 3).map((f) => (
                    <td key={f.key} className="px-4 py-2.5 text-primary-900 dark:text-sable max-w-xs truncate">
                      {f.type === 'checkbox' ? (item[f.key] ? 'Oui' : 'Non') : String(item[f.key] ?? '')}
                    </td>
                  ))}
                  <td className="px-4 py-2.5 flex justify-end gap-1">
                    <button onClick={() => startEdit(item)} className="p-1.5 rounded-lg hover:bg-primary-100 dark:hover:bg-primary-700 text-primary-500"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(item.id)} className="p-1.5 rounded-lg hover:bg-urgence-100 text-urgence-500"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={() => setEditing(null)}>
          <div onClick={(e) => e.stopPropagation()} className="bg-white dark:bg-primary-700 rounded-2xl shadow-glass w-full max-w-md p-5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-display font-bold text-primary-900 dark:text-sable">{editing.id ? 'Modifier' : 'Ajouter'} — {title}</h4>
              <button onClick={() => setEditing(null)}><X className="w-5 h-5 text-primary-300" /></button>
            </div>
            <div className="space-y-3">
              {fields.map((f) => (
                <div key={f.key}>
                  <label className="text-xs font-semibold text-primary-300 uppercase tracking-wide">{f.label}</label>
                  {f.type === 'textarea' ? (
                    <textarea
                      value={editing[f.key] || ''}
                      onChange={(e) => setEditing((ed) => ({ ...ed, [f.key]: e.target.value }))}
                      rows={3}
                      className="w-full mt-1 px-3 py-2 rounded-xl border border-primary-100 dark:border-white/10 bg-white/80 dark:bg-primary-900/40 focus:outline-none focus:ring-2 focus:ring-mint-500"
                    />
                  ) : f.type === 'checkbox' ? (
                    <input
                      type="checkbox"
                      checked={Boolean(editing[f.key])}
                      onChange={(e) => setEditing((ed) => ({ ...ed, [f.key]: e.target.checked }))}
                      className="mt-1 w-5 h-5 accent-mint-500"
                    />
                  ) : f.type === 'select' ? (
                    <select
                      value={editing[f.key] || ''}
                      onChange={(e) => setEditing((ed) => ({ ...ed, [f.key]: e.target.value }))}
                      className="w-full mt-1 px-3 py-2 rounded-xl border border-primary-100 dark:border-white/10 bg-white/80 dark:bg-primary-900/40 focus:outline-none focus:ring-2 focus:ring-mint-500"
                    >
                      <option value="">—</option>
                      {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
                    </select>
                  ) : (
                    <input
                      type={f.type === 'color' ? 'color' : f.type === 'number' ? 'number' : 'text'}
                      value={editing[f.key] || ''}
                      onChange={(e) => setEditing((ed) => ({ ...ed, [f.key]: e.target.value }))}
                      className="w-full mt-1 px-3 py-2 rounded-xl border border-primary-100 dark:border-white/10 bg-white/80 dark:bg-primary-900/40 focus:outline-none focus:ring-2 focus:ring-mint-500"
                    />
                  )}
                </div>
              ))}
            </div>
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full mt-5 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-mint-500 hover:bg-mint-700 text-white font-semibold disabled:opacity-60"
            >
              <Save className="w-4 h-4" /> {saving ? 'Enregistrement…' : 'Enregistrer'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
