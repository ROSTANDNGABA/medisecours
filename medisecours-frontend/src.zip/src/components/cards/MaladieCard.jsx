import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import GravityBadge from '../ui/GravityBadge'
import UrgencyBadge from '../ui/UrgencyBadge'

export default function MaladieCard({ maladie }) {
  const categoryColor = maladie.categorie?.couleur || '#6B9E78'
  
  return (
    <Link
      href={`/maladies/${maladie.id}`}
      className="group relative overflow-hidden rounded-2xl p-6 border border-white/40 dark:border-white/10 shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
      style={{ backgroundColor: `${categoryColor}14` }}
    >
      <div
        className="absolute -right-6 -top-6 w-24 h-24 rounded-full opacity-20 group-hover:scale-125 transition-transform duration-500"
        style={{ backgroundColor: categoryColor }}
      />
      <div className="relative">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span
              className="inline-block w-3 h-3 rounded-full"
              style={{ backgroundColor: categoryColor }}
            />
            {maladie.categorie && (
              <span
                className="text-xs font-medium px-2 py-0.5 rounded-full"
                style={{ backgroundColor: `${categoryColor}22`, color: categoryColor }}
              >
                {maladie.categorie.nom}
              </span>
            )}
          </div>
          {maladie.urgence && <UrgencyBadge>Urgent</UrgencyBadge>}
        </div>
        
        <h3 className="font-display font-bold text-lg text-primary-900 dark:text-sable mb-2 line-clamp-2">
          {maladie.nom}
        </h3>
        
        <p className="text-sm text-primary-300 line-clamp-2 mb-4">{maladie.symptomes}</p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 flex-wrap">
            <GravityBadge level={maladie.niveauGravite} />
            {maladie.contagieux && (
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300">
                Contagieux
              </span>
            )}
          </div>
          <ArrowUpRight className="w-4 h-4 text-primary-300 group-hover:text-mint-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
        </div>
      </div>
    </Link>
  )
}
