import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'

export default function CategoryCard({ category }) {
  const count = category.maladies?.length ?? 0
  const bgColor = category.couleur || '#E8B4B8'
  
  return (
    <Link
      href={`/categories/${category.id}`}
      className="group relative overflow-hidden rounded-3xl p-6 border border-white/20 dark:border-white/5 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 h-[220px] flex flex-col"
      style={{ 
        background: `linear-gradient(135deg, ${bgColor}08 0%, ${bgColor}18 100%)`,
      }}
    >
      {/* Point coloré en haut à gauche */}
      <div className="absolute top-6 left-6">
        <span
          className="block w-3 h-3 rounded-full shadow-lg"
          style={{ backgroundColor: bgColor }}
        />
      </div>

      {/* Grand cercle décoratif en haut à droite */}
      <div
        className="absolute -right-12 -top-12 w-32 h-32 rounded-full opacity-30 group-hover:scale-110 group-hover:opacity-40 transition-all duration-700"
        style={{ backgroundColor: bgColor }}
      />

      <div className="relative flex-1 flex flex-col pt-6">
        {/* Titre */}
        <h3 className="font-display font-bold text-xl text-primary-900 dark:text-sable mb-2 leading-tight">
          {category.nom}
        </h3>
        
        {/* Description */}
        <p className="text-sm text-primary-400/80 dark:text-primary-300/70 line-clamp-2 mb-auto leading-relaxed">
          {category.description}
        </p>

        {/* Footer avec compteur et icône */}
        <div className="flex items-center justify-between mt-4 pt-3">
          <span className="text-xs font-semibold px-3 py-1.5 rounded-full bg-white/90 dark:bg-primary-800/60 text-primary-700 dark:text-sable shadow-sm">
            {count} maladie{count > 1 ? 's' : ''}
          </span>
          <div className="w-9 h-9 rounded-full bg-white/70 dark:bg-primary-800/50 flex items-center justify-center group-hover:bg-mint-500/20 transition-colors duration-300">
            <ArrowUpRight 
              className="w-4 h-4 text-primary-700 dark:text-sable group-hover:text-mint-500 group-hover:translate-x-1 group-hover:-translate-y-1 transition-all duration-300" 
            />
          </div>
        </div>
      </div>
    </Link>
  )
}
